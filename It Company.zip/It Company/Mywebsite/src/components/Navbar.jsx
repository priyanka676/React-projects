import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
  <>

    <div className="page-wrapper">
        <header className="main-header">
            <div className="main-menu__top">
                <div className="main-menu__top-inner">
                    <ul className="list-unstyled main-menu__contact-list">
                        <li>
                            <div className="icon">
                                <i className="icon-email"></i>
                            </div>
                            <div className="text">
                                <p><a href="mailto:info@Itzone24.com">info@Itzone25.com</a>
                                </p>
                            </div>
                        </li>
                        <li>
                            <div className="icon">
                                <i className="icon-pin"></i>
                            </div>
                            <div className="text">
                                <p>4124 Cimmaron Road, CA 92806</p>
                            </div>
                        </li>
                    </ul>
                    <p className="main-menu__top-welcome-text">Welcome to Itzone
                        our Best Technology HTML5 Template</p>
                    <div className="main-menu__top-right">
                        <p className="main-menu__social-title">Follow Us On:</p>
                        <div className="main-menu__social">
                            <a href="#"><i className="fab fa-twitter"></i></a>
                            <a href="#"><i className="fab fa-facebook"></i></a>
                            <a href="#"><i className="fab fa-pinterest-p"></i></a>
                            <a href="#"><i className="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <nav className="main-menu">
                <div className="main-menu__wrapper">
                    <div className="main-menu__wrapper-inner">
                        <div className="main-menu__left">
                            <div className="main-menu__logo">
                                <a href="index.html">
                                    <img src="images/resources/logo-1.png" alt="" /></a>
                            </div>
                        </div>
                        <div className="main-menu__main-menu-box">
                            <a href="#" className="mobile-nav__toggler"><i className="fa fa-bars"></i></a>
                            <ul className="main-menu__list">
                                <li className="dropdown megamenu">
                                    <Link to="/home">Home </Link>
                                    
                                </li>
                                <li>
                                    <Link to="/about">About</Link>
                                </li>
                                
                                <li className="dropdown">
                                    <Link to="/services">services</Link>
                                
                                </li>
                               
                                <li className="dropdown">
                                    <Link to="/blog">Blog</Link>
                               
                                </li>
                                <li>
                                    <Link to="/contact">Contact</Link>
                                </li>
                                <li className="dropdown">
                                    <Link to="/login">Login</Link>
                                   
                                </li>
                                <li className="dropdown">
                                    <Link to="/register">Register</Link>
                                   
                                </li>
                            </ul>
                        </div>
                        <div className="main-menu__right">
                          
                           
                            <div className="main-menu__btn-box">
                                <Link to="/about" className="thm-btn">Discover More
                                    <span className="fas fa-arrow-right"></span>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            </header>
     </div>
     {/* <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div>
            </div> */}
   
  </>
  )
}

export default Navbar