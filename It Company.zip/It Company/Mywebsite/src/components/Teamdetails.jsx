import React from 'react'

const Teamdetails = () => {
  return (
   <section>
     <section className="page-header">
            <div className="page-header__bg" style={{backgroundImage: "url('images/backgrounds/page-header-bg.jpg')"}}>
            </div>
            <div className="container">
                <div className="page-header__inner">
                    <h3>Team Details</h3>
                    <div className="thm-breadcrumb__inner">
                        <ul className="thm-breadcrumb list-unstyled">
                            <li><a href="index.html">Home</a></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li>Team Details</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section className="team-details">
            <div className="container">
                <div className="team-details__top">
                    <div className="row">
                        <div className="col-xl-5 col-lg-5">
                            <div className="team-details__top-left">
                                <div className="team-details__img-1">
                                    <img src="images/team/team-details-img-1.jpg" alt="" />
                                </div>
                            </div>
                        </div>
                        <div className="col-xl-7 col-lg-7">
                            <div className="team-details__top-right">
                                <div className="team-details__client-box">
                                    <h3 className="team-details__client-name">Amaina Anne</h3>
                                    <span className="team-details__client-sub-title">Professional UI/UX Design</span>
                                    <div className="team-details__social">
                                        <a href="#"><i className="icon-facebook-app-symbol"></i></a>
                                        <a href="#"><i className="icon-twitter-1"></i></a>
                                        <a href="#"><i className="icon-linkedin"></i></a>
                                        <a href="#"><i className="icon-pinterest"></i></a>
                                    </div>
                                    <p className="team-details__client-text">Neque porro quisquam est, qui dolorem ipsum
                                        quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi
                                        tempora incidunt ut labore et dolore ma gnam aliquam quaerat voluptatem. Ut enim
                                        ad minima veniam</p>
                                    <ul className="team-details__client-address list-unstyled">
                                        <li>
                                            <p><span className="icon-pin"></span>Address</p>
                                            <h5>4140 Parker Rd. Allentown, New Mexico 31134</h5>
                                        </li>
                                        <li>
                                            <p><span className="icon-call"></span>Phone Number</p>
                                            <h5><a href="tel:2085550112">(208) 555-0112</a></h5>
                                        </li>
                                        <li>
                                            <p><span className="icon-email"></span>Email</p>
                                            <h5><a href="mailto:michael.mitc@example.com">michael.mitc@example.com</a>
                                            </h5>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="team-details__bottom">
                    <div className="row">
                        <div className="col-xl-6 col-lg-6">
                            <div className="team-details__bottom-left">
                                <h3 className="team-details__bottom-title">Biography</h3>
                                <p className="team-details__bottom-text">Neque porro quisquam est, qui dolorem ipsum quia
                                    dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora
                                    incidunt ut labore et dolore ma gnam aliquam quaerat voluptatem. Ut enim ad minima
                                    veniam</p>
                                <div className="team-details__practice-area">
                                    <h4 className="team-details__practice-area-title">Practice Area</h4>
                                    <div className="team-details__practice-area-list-box">
                                        <ul className="list-unstyled team-details__practice-area-list">
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>UI/UX Design</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>APP Development</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>Product Design</p>
                                                </div>
                                            </li>
                                        </ul>
                                        <ul
                                            className="list-unstyled team-details__practice-area-list team-details__practice-area-list--two">
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>Website Design</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>Business Analysis</p>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="icon"></div>
                                                <div className="text">
                                                    <p>Web Devolopment</p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-xl-6 col-lg-6">
                            <div className="team-details__bottom-right">
                                <h3 className="team-details__progress-title-1">Skills</h3>
                                <ul className="team-details__progress-list list-unstyled">
                                    <li>
                                        <div className="team-details__progress">
                                            <h4 className="team-details__progress-title">Repair Device</h4>
                                            <div className="bar">
                                                <div className="bar-inner count-bar" data-percent="80%">
                                                    <div className="count-text">80%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="team-details__progress">
                                            <h4 className="team-details__progress-title">Replace Device</h4>
                                            <div className="bar">
                                                <div className="bar-inner count-bar" data-percent="95%">
                                                    <div className="count-text">95%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="team-details__progress">
                                            <h4 className="team-details__progress-title">Diagnostics</h4>
                                            <div className="bar">
                                                <div className="bar-inner count-bar" data-percent="65%">
                                                    <div className="count-text">65%</div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section className="team-details-contact">
            <div className="container">
                <div className="section-title text-center sec-title-animation animation-style1">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">Contact Our
                            Team</span>
                    </div>
                    <h2 className="section-title__title title-animation">Give Us A <span>Message</span>
                    </h2>
                </div>
                <div className="team-details-contact__inner">
                    <form className="contact-form-validated team-details-contact__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                        method="post">
                        <div className="row">
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="team-details-contact__input-box">
                                    <input type="text" name="name" placeholder="Your Name" required="" />
                                </div>
                            </div>
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="team-details-contact__input-box">
                                    <input type="email" name="Email" placeholder="Email Address" required="" />
                                </div>
                            </div>
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="team-details-contact__input-box">
                                    <input type="text" name="Phone" placeholder="Phone Number" required="" />
                                </div>
                            </div>
                            <div className="col-xl-6 col-lg-6 col-md-6">
                                <div className="team-details-contact__input-box">
                                    <input type="text" name="subject" placeholder="Subject" required="" />
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="team-details-contact__input-box text-message-box">
                                    <textarea name="message" placeholder="Messege" required="" ></textarea>
                                </div>
                                <div className="team-details-contact__btn-box">
                                    <button type="submit" className="thm-btn">send a
                                        message
                                        <span className="fas fa-arrow-right"></span> </button>
                                </div>
                            </div>
                        </div>
                        <div className="result"></div>
                    </form>
                </div>
            </div>
        </section>
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
   </section>
  )
}

export default Teamdetails