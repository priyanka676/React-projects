import React from 'react'

const Productdesign = () => {
  return (
   <section>
       <section className="page-header">
            <div className="page-header__bg" style={{backgroundImage: "url('images/backgrounds/page-header-bg.jpg')"}}>
            </div>
            <div className="container">
                <div className="page-header__inner">
                    <h3>Product Design</h3>
                    <div className="thm-breadcrumb__inner">
                        <ul className="thm-breadcrumb list-unstyled">
                            <li><a href="index.html">Home</a></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li><a href="services.html">Services</a></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li>Product Design</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section className="service-details">
            <div className="container">
                <div className="row">
                    <div className="col-xl-4 col-lg-5">
                        <div className="service-details__sidebar">
                            <div className="service-details__services-box">
                                <h3 className="service-details__services-title">Our Services</h3>
                                <ul className="service-details__services-list list-unstyled">
                                    <li>
                                        <a href="ui-ux-design.html">UI/UX Design<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                    <li>
                                        <a href="web-development.html">Web Development<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                    <li>
                                        <a href="digital-marketing.html">Digital Marketing<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                    <li>
                                        <a href="business-analysis.html">Business Analysis<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                    <li>
                                        <a href="software-development.html">Software Development<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                    <li className="active">
                                        <a href="product-design.html">Product Design<span
                                                className="icon-arrow-right"></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div className="service-details__get-started">
                                <h3 className="service-details__get-started-title">Get Started Today</h3>
                                <p className="service-details__get-started-text">Pianissimos of dulcimers qui therefore
                                    always
                                    holds in these matters to this principle</p>
                                <ul className="service-details__get-started-points list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-call"></span>
                                        </div>
                                        <p><a href="tel:585858575084">+58 585 857 5084</a></p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-email"></span>
                                        </div>
                                        <p><a href="mailto:example@gmail.com">example@gmail.com</a></p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-pin"></span>
                                        </div>
                                        <p>4517 Washington Ave. Manchester,<br /> Kentucky 39495</p>
                                    </li>
                                </ul>
                                <div className="service-details__get-started-btn-box">
                                    <a href="contact.html" className="thm-btn">get in
                                        touch <span className="fas fa-arrow-right"></span></a>
                                </div>
                            </div>
                            <div className="service-details__sidebar-download-box">
                                <h3 className="service-details__services-title">Download</h3>
                                <div className="service-details__sidebar-single-download">

                                    <ul className="clearfix list-unstyled">
                                        <li>
                                            <div className="content-box">
                                                <div className="icon">
                                                    <span className="far fa-file-pdf"></span>
                                                </div>
                                                <div className="text-box">
                                                    <h5><a href="#">Pdf Download</a></h5>
                                                    <p><a href="#">Download</a></p>
                                                </div>
                                            </div>

                                            <div className="btn-box">
                                                <a href="#"><span className="far fa-cloud-download"></span></a>
                                            </div>
                                        </li>

                                        <li>
                                            <div className="content-box">
                                                <div className="icon">
                                                    <span className="far fa-file-pdf"></span>
                                                </div>
                                                <div className="text-box">
                                                    <h5><a href="#">Pdf Download</a></h5>
                                                    <p><a href="#">Download</a></p>
                                                </div>
                                            </div>

                                            <div className="btn-box">
                                                <a href="#"><span className="far fa-cloud-download"></span></a>
                                            </div>
                                        </li>

                                        <li>
                                            <div className="content-box">
                                                <div className="icon">
                                                    <span className="far fa-file-pdf"></span>
                                                </div>
                                                <div className="text-box">
                                                    <h5><a href="#">Pdf Download</a></h5>
                                                    <p><a href="#">Download</a></p>
                                                </div>
                                            </div>

                                            <div className="btn-box">
                                                <a href="#"><span className="far fa-cloud-download"></span></a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-8 col-lg-7">
                        <div className="service-details__left">
                            <div className="service-details__img">
                                <img src="images/services/service-details-img-6.jpg" alt="" />
                            </div>
                            <h3 className="service-details__title-1">Product Design</h3>
                            <p className="service-details__text-1">Ut enim ad minim veniam, quis nostrud exercitation
                                ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
                                sint occaecat cupidatat non proident, sunt in culpa</p>
                            <p className="service-details__text-2">Consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut laborer et dolore magna aliqua. Out enigma ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute inure
                                dolor in the reprehenderit in voluptate velit esse cillum dolore eu fugiat null
                                pariatur. Excepteur snit occaecat cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <ul className="service-details__points-list list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check"></span>
                                    </div>
                                    <p>It is a long established fact that a reader will be distr acted bioiiy the rea
                                        dablea </p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check"></span>
                                    </div>
                                    <p>Distr acted bioiiy the rea dablea content of a page when looking at its layout
                                    </p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check"></span>
                                    </div>
                                    <p>Content of a page when looking at its layout toile point</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check"></span>
                                    </div>
                                    <p>Reader will be distr acted bioiiy the rea dablea content of a page when looking
                                    </p>
                                </li>
                            </ul>
                            <div className="service-details__img-box">
                                <div className="row">
                                    <div className="col-xl-6">
                                        <div className="service-details__img-box-single">
                                            <div className="service-details__img-box-img">
                                                <img src="images/services/service-details-img-box-img-1.jpg"
                                                    alt="" />
                                            </div>
                                            <div className="service-details__img-box-content">
                                                <div className="service-details__img-box-content-icon-and-title">
                                                    <div className="service-details__img-box-content-icon">
                                                        <span className="icon-financial"></span>
                                                    </div>
                                                    <h3 className="service-details__img-box-content-title">Quality Full Work
                                                    </h3>
                                                </div>
                                                <p className="service-details__img-box-content-text">Duis acute arura dolor
                                                    in
                                                    reprehenderit in voluptate velit esse cillum dolore Velit esse quam
                                                    nihil molestiae thos consequatur, Velia ease chillum dolore</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-xl-6">
                                        <div className="service-details__img-box-single">
                                            <div className="service-details__img-box-img">
                                                <img src="images/services/service-details-img-box-img-2.jpg"
                                                    alt="" />
                                            </div>
                                            <div className="service-details__img-box-content">
                                                <div className="service-details__img-box-content-icon-and-title">
                                                    <div className="service-details__img-box-content-icon">
                                                        <span className="icon-certified"></span>
                                                    </div>
                                                    <h3 className="service-details__img-box-content-title">100% Work
                                                        Satisfication</h3>
                                                </div>
                                                <p className="service-details__img-box-content-text">Duis acute arura dolor
                                                    in
                                                    reprehenderit in voluptate velit esse cillum dolore Velit esse quam
                                                    nihil molestiae thos consequatur, Velia ease chillum dolore</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="service-details__faq-box">
                                <div className="accrodion-grp" data-grp-name="faq-one-accrodion">
                                    <div className="accrodion">
                                        <div className="accrodion-title">
                                            <h4>How long should a business plan be</h4>
                                        </div>
                                        <div className="accrodion-content">
                                            <div className="inner">
                                                <p>From personalized solutions to expert execution, we prioritize
                                                    quality,
                                                    reliability, and customer satisfaction in everything we do. Let us
                                                    be
                                                    your trusted partner in achieving success.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="accrodion active">
                                        <div className="accrodion-title">
                                            <h4>Do I need a business plan?</h4>
                                        </div>
                                        <div className="accrodion-content">
                                            <div className="inner">
                                                <p>From personalized solutions to expert execution, we prioritize
                                                    quality,
                                                    reliability, and customer satisfaction in everything we do. Let us
                                                    be
                                                    your trusted partner in achieving success.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="accrodion">
                                        <div className="accrodion-title">
                                            <h4>How to Soft Launch Your Business?</h4>
                                        </div>
                                        <div className="accrodion-content">
                                            <div className="inner">
                                                <p>From personalized solutions to expert execution, we prioritize
                                                    quality,
                                                    reliability, and customer satisfaction in everything we do. Let us
                                                    be
                                                    your trusted partner in achieving success.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="accrodion">
                                        <div className="accrodion-title">
                                            <h4>How Can I Find My Solution?</h4>
                                        </div>
                                        <div className="accrodion-content">
                                            <div className="inner">
                                                <p>From personalized solutions to expert execution, we prioritize
                                                    quality,
                                                    reliability, and customer satisfaction in everything we do. Let us
                                                    be
                                                    your trusted partner in achieving success.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
   </section>
  )
}

export default Productdesign