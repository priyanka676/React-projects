import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'

const Projects = () => {
  return (
    <>
    <Navbar />
      <section className="page-header">
            <div className="page-header__bg" style={{backgroundImage: "url('images/backgrounds/page-header-bg.jpg')"}}>
            </div>
            <div className="container">
                <div className="page-header__inner">
                    <h3>projects</h3>
                    <div className="thm-breadcrumb__inner">
                        <ul className="thm-breadcrumb list-unstyled">
                            <li><a href="index.html">Home</a></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li>projects</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <section className="project-page">
            <div className="container">
                <div className="row">
                   
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-1.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-1.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">UI/UX Development</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="200ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-2.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-2.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Business Analysis</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="300ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-3.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-3.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Product
                                            Development</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="400ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-4.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-4.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Digital Experience</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="500ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-5.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-5.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Digital Marketing</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="600ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-6.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-6.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Cloud Computing</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="700ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-7.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-7.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">Software Service</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="800ms">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="images/project/project-2-8.jpg" alt="" />
                                    <div className="project-two__arrow">
                                        <a href="images/project/project-2-8.jpg" className="img-popup"><span
                                                className="fas fa-arrow-right"></span></a>
                                    </div>
                                </div>
                                <div className="project-two__content">
                                    <h3 className="project-two__title"><a href="project-details.html">SEO Optimization</a>
                                    </h3>
                                    <p className="project-two__sub-title">Technology</p>
                                </div>
                            </div>
                        </div>
                    </div>
               
                </div>
            </div>
        </section>
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <Footer />
    </>
  )
}

export default Projects