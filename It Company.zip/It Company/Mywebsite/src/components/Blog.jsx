import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Blog = () => {
  return (
   <>
   <Navbar />
   <section className="page-header">
            <div className="page-header__bg" >
            </div>
            <div className="container about-section" style={{height:"400px"}}>
                <div className="page-header__inner">
                    <h3  className='text-center text-white fw-bolder ' style={{fontSize:"100px"}}>Blog</h3>
                   
                </div>
            </div>
        </section>
        <section className="blog-left-sidebar">
            <div className="container">
                <div className="row">
                  
                    <div className="col-xl-4">
                        <div className="sidebar sidebar--two">

                            <div className="sidebar__single sidebar__search wow fadeInUp" data-wow-delay=".1s">
                                <form action="#" className="sidebar__search-form">
                                    <input type="search" placeholder="Search..." />
                                    <button type="submit"><i className="fa fa-search"></i></button>
                                </form>
                            </div>
                            
                            <div className="sidebar__single sidebar__category wow fadeInUp" data-wow-delay=".1s">
                                <h3 className="sidebar__title">Categories</h3>
                                <ul className="sidebar__category-list list-unstyled">
                                    <li><a href="#">IT Solution <span>(12)</span></a></li>
                                    <li className="active"><a href="#">SEO Marketing
                                            <span>(15)</span></a></li>
                                    <li><a href="#">Web Development <span>(08)</span></a></li>
                                    <li><a href="#">UI/UX Design <span>(20)</span></a></li>
                                    <li><a href="#">Cloud Solution <span>(14)</span></a></li>
                                    <li><a href="#">Products Design <span>(05)</span></a></li>
                                </ul>
                            </div>
                          
                            <div className="sidebar__single sidebar__post wow fadeInUp" data-wow-delay=".1s">
                                <h3 className="sidebar__title">Recent Post</h3>
                                <ul className="sidebar__post-list list-unstyled">
                                    <li>
                                        <div className="sidebar__post-image">
                                            <img src="images/blog/blog-lp-1.jpg" alt="" />
                                        </div>
                                        <div className="sidebar__post-content">
                                            <p className="sidebar__post-date"><span className="icon-calendar"></span>March 18,
                                                2025</p>
                                            <h3 className="sidebar__post-title">
                                                <Link href="/blogdetails">Adapting to
                                                    Digital Marketing Trends: Staying Ahead</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="sidebar__post-image">
                                            <img src="images/blog/blog-lp-2.jpg" alt="" />
                                        </div>
                                        <div className="sidebar__post-content">
                                            <p className="sidebar__post-date"><span className="icon-calendar"></span>April 18,
                                                2025</p>
                                            <h3 className="sidebar__post-title"><a href="blogdetails">Standing Out in
                                                    a Competitive Market: </a></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="sidebar__post-image">
                                            <img src="images/blog/blog-lp-3.jpg" alt="" />
                                        </div>
                                        <div className="sidebar__post-content">
                                            <p className="sidebar__post-date"><span className="icon-calendar"></span>Jun 18,
                                                2025</p>
                                            <h3 className="sidebar__post-title"><Link href="blogdetails">The Importance
                                                    of Accurate Performance Reporting </Link></h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                      
                            <div className="sidebar__single sidebar__tags wow fadeInUp" data-wow-delay=".1s">
                                <h3 className="sidebar__title">Tags Cloud</h3>
                                <ul className="sidebar__tags-list clearfix list-unstyled">
                                    <li><a href="#">Development</a></li>
                                    <li><a href="#">Start Up</a></li>
                                    <li><a href="#">Agency</a></li>
                                    <li><a href="#">Innovation</a></li>
                                    <li><a href="#">Analytics</a></li>
                                    <li><a href="#">Business</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">Technology</a></li>
                                </ul>
                            </div>
                           

                        </div>
                    </div>
                   
                    <div className="col-xl-8">
                        <div className="row">
                            
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-1.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-1.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Malaika alise</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span
                                                        className="far fa-calendar-alt"></span>April 5,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title"><Link to="/blogdetails">Improving Business
                                                Growth with
                                                New Technology</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-2.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-2.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Readik males</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span
                                                        className="far fa-calendar-alt"></span>April 5,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title"><Link to="/blogdetails">Regional Manager &
                                                limited
                                                management.</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Read More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-3.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-3.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Tamu Tanu</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span
                                                        className="far fa-calendar-alt"></span>April 5,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title">
                                            <Link to="/blogdetails">Easy and Most Powerful
                                                Server
                                                and Platform.</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-4.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-4.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Hardik Pandey</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span className="far fa-calendar-alt"></span>Aug
                                                    9,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title">
                                            <Link to="/blogdetails">Improving Business
                                                Growth with
                                                New Technology</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-5.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-5.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Ronalfi Kenis</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span className="far fa-calendar-alt"></span>may
                                                    14,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title">
                                            <Link to="/blogdetails">Regional Manager &
                                                limited
                                                management.</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-6.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-6.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Tapila Gos</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span
                                                        className="far fa-calendar-alt"></span>Janu 15,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title"><a to="/blogdetails">Easy and Most Powerful
                                                Server
                                                and Platform.</a></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-7.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-7.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">David Koper</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span className="far fa-calendar-alt"></span>May
                                                    12,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title"><a to="/blogdetails">Cloud vs. On-Premise Is
                                                Right for You?</a></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                         
                            <div className="col-xl-6 col-lg-6">
                                <div className="blog-one__single">
                                    <div className="blog-one__img">
                                        <img src="images/blog/blog-2-8.jpg" alt="" />
                                        <div className="blog-one__tags">
                                            <span>Digital</span>
                                            <span>Technology</span>
                                        </div>
                                    </div>
                                    <div className="blog-one__content">
                                        <div className="blog-one__user">
                                            <div className="blog-one__user-img">
                                                <img src="images/blog/blog-one-user-8.jpg" alt="" />
                                            </div>
                                            <p className="blog-one__user-title">Warner Koper</p>
                                        </div>
                                        <ul className="blog-one__meta list-unstyled">
                                            <li>
                                                <Link to="/blogdetails"><span
                                                        className="far fa-calendar-alt"></span>April 5,
                                                    2025</Link>
                                            </li>
                                            <li>
                                                <Link to="/blogdetails"><span className="fal fa-comments"></span>80
                                                    Comments</Link>
                                            </li>
                                        </ul>
                                        <h3 className="blog-one__title">
                                            <Link to="/blogdetails">The Role of AI in IT
                                                Support and Security</Link></h3>
                                        <div className="blog-one__btn-box">
                                            <Link to="/blogdetails" className="thm-btn">Reed More
                                                <span className="fas fa-arrow-right"></span>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <Footer />
   </> 
  )
}

export default Blog