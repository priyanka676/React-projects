import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Register = () => {
  return (
  <>
  <Navbar />

        <section className="page-header">
            <div className="page-header__bg" >
            </div>
            <div className="container about-section" style={{height:"400px"}}>
                <div className="page-header__inner">
                    <h3 className='text-center text-white fw-bolder ' style={{fontSize:"100px"}}>Sign Up</h3>
                </div>
            </div>
        </section>
    
        <section className="sign-up-one">
            <div className="container">
                <div className="sign-up-one__form">
                    <div className="inner-title text-center">
                        <h2>Sing Up</h2>
                    </div>
                    <form id="sign-up-one__form" name="sign-up-one_form" action="/register" method="post">
                        <div className="row">
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="text" name="name" id="formName" placeholder="Name..."
                                            required=""  />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="email" name="email" id="formEmail" placeholder="Email..."
                                            required=""  />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="text" name="phone" id="formPhone" placeholder="Phone..."
                                            required="" value="" />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="text" name="password" id="formPassword"
                                            placeholder="Password..." required=""  />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <button className="thm-btn" type="submit" data-loading-text="Please wait...">Sign UP
                                        <span><i className="icon-right-arrow"></i></span></button>
                                </div>
                            </div>
                        </div>
                        <div className="google-facebook">
                            <a href="https://www.google.com/">
                                <div className="icon">
                                    <img src="images/icon/icon-google-2.png" alt="Google" />
                                </div>
                                Continue with Google
                            </a>
                            <a href="https://www.facebook.com/">
                                <div className="icon">
                                    <img src="images/icon/icon-facebook.png" alt="Google" />
                                </div>
                                Continue with Facebook
                            </a>
                        </div>
                        <div className="create-account text-center">
                            <p>Already have an account? <Link to="/login">Login Here</Link></p>
                        </div>
                    </form>
                </div>
            </div>
        </section>
      
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <Footer />
      
  </>
  )
}

export default Register