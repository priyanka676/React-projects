import React from 'react'


const Cart = () => {
  return (
<>

  
<section className="page-header">
            <div className="page-header__bg" >
            </div>
            <div className="container about-section" style={{height:"400px"}}>
                <div className="page-header__inner">
                    <h3  className='text-center text-white fw-bolder ' style={{paddingTop:"150px",fontSize:"100px"}}>Cart</h3>
                   
                </div>
            </div>
        </section>
<section classname="cart-page">
            <div classname="container">
                <div classname="row">
                    <div classname="col-xl-8 col-lg-7">
                        <div classname="cart-page__left">
                            <div classname="table-responsive">
                                <table classname="table cart-table">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total</th>
                                            <th>Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td>
                                                <div classname="product-box">
                                                    <div classname="img-box">
                                                        <img src="images/shop/cart-page-img-1.jpg" alt="" />
                                                    </div>
                                                    <h3><a href="product-details.html">Gree Air Conditioner</a></h3>
                                                </div>
                                            </td>
                                            <td>$10.99</td>
                                            <td>
                                                <div classname="quantity-box">
                                                    <button type="button" classname="sub"><i
                                                            classname="fa fa-minus"></i></button>
                                                    <input type="number" id="product-1" value="1" />
                                                    <button type="button" classname="add"><i
                                                            classname="fa fa-plus"></i></button>
                                                </div>
                                            </td>
                                            <td>
                                                $10.99
                                            </td>
                                            <td>
                                                <div classname="cross-icon">
                                                    <i classname="fas fa-times"></i>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div classname="product-box">
                                                    <div classname="img-box">
                                                        <img src="images/shop/cart-page-img-2.jpg" alt="" />
                                                    </div>
                                                    <h3><a href="product-details.html">Pliers | Cutting, Gripping</a>
                                                    </h3>
                                                </div>
                                            </td>
                                            <td>$10.99</td>
                                            <td>
                                                <div classname="quantity-box">
                                                    <button type="button" classname="sub"><i
                                                            classname="fa fa-minus"></i></button>
                                                    <input type="number" id="product-2" value="1" />
                                                    <button type="button" classname="add"><i
                                                            classname="fa fa-plus"></i></button>
                                                </div>
                                            </td>
                                            <td>
                                                $10.99
                                            </td>
                                            <td>
                                                <div classname="cross-icon">
                                                    <i classname="fas fa-times"></i>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div classname="product-box">
                                                    <div classname="img-box">
                                                        <img src="images/shop/cart-page-img-3.jpg" alt="" />
                                                    </div>
                                                    <h3><a href="product-details.html">Gear and wrench</a></h3>
                                                </div>
                                            </td>
                                            <td>$10.99</td>
                                            <td>
                                                <div classname="quantity-box">
                                                    <button type="button" classname="sub"><i
                                                            classname="fa fa-minus"></i></button>
                                                    <input type="number" id="product-3" value="1" />
                                                    <button type="button" classname="add"><i
                                                            classname="fa fa-plus"></i></button>
                                                </div>
                                            </td>
                                            <td>
                                                $10.99
                                            </td>
                                            <td>
                                                <div classname="cross-icon">
                                                    <i classname="fas fa-times"></i>
                                                </div>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td>
                                                <div classname="product-box">
                                                    <div classname="img-box">
                                                        <img src="images/shop/cart-page-img-4.jpg" alt="" />
                                                    </div>
                                                    <h3><a href="product-details.html">Nut Driver</a></h3>
                                                </div>
                                            </td>
                                            <td>$10.99</td>
                                            <td>
                                                <div classname="quantity-box">
                                                    <button type="button" classname="sub"><i
                                                            classname="fa fa-minus"></i></button>
                                                    <input type="number" id="product-4" value="1" />
                                                    <button type="button" classname="add"><i
                                                            classname="fa fa-plus"></i></button>
                                                </div>
                                            </td>
                                            <td>
                                                $10.99
                                            </td>
                                            <td>
                                                <div classname="cross-icon">
                                                    <i classname="fas fa-times"></i>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div classname="col-xl-4 col-lg-5">
                        <div classname="cart-page__right">
                            <div classname="cart-page__sidebar">
                                <div classname="cart-page__shipping">
                                    <h3 classname="cart-page__shipping-title">Calculated Shipping</h3>
                                    <form action="#" classname="cart-page__shipping-form">
                                        <div classname="row">
                                            <div classname="col-xl-12">
                                                <div classname="cart-page__shipping-input-box">
                                                    <div classname="select-box">
                                                        <select classname="wide">
                                                            <option data-display="Country">Country</option>
                                                            <option value="1">Ban</option>
                                                            <option value="2">Ind</option>
                                                            <option value="3">Pak</option>
                                                            <option value="3">USA</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div classname="col-xl-6 col-lg-6 col-md-6">
                                                <div classname="cart-page__shipping-input-box">
                                                    <div classname="select-box">
                                                        <select classname="wide">
                                                            <option data-display="State/City">State/City</option>
                                                            <option value="1">Ban</option>
                                                            <option value="2">Ind</option>
                                                            <option value="3">Pak</option>
                                                            <option value="3">USA</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div classname="col-xl-6 col-lg-6 col-md-6">
                                                <div classname="cart-page__shipping-input-box">
                                                    <input type="text" placeholder="Zip Code" />
                                                </div>
                                            </div>
                                            <div classname="cart-page__btn-box">
                                                <button type="submit" classname="thm-btn">
                                                    Update <span classname="fas fa-arrow-right"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div classname="cart-page__coupon-code">
                                    <h3 classname="cart-page__coupon-code-title">Coupon Code</h3>
                                    <p classname="cart-page__coupon-code-text">I must explain to you how all this mistaken
                                        idea of denouncing pleasure and praising pain was born</p>
                                    <form action="#" classname="default-form cart-page__coupon-code-form">
                                        <input type="text" placeholder="Enter Coupon Code" />
                                        <button classname="thm-btn" type="submit">
                                            Apply Coupon <span classname="fas fa-arrow-right"></span>
                                        </button>
                                    </form>
                                </div>
                                <div classname="cart-page__cart-total">
                                    <ul classname="cart-total list-unstyled">
                                        <li>
                                            <span>Cart Subtotal</span>
                                            <span>$20.98 USD </span>
                                        </li>
                                        <li>
                                            <span>Shipping Cost</span>
                                            <span>-$40.00 USD</span>
                                        </li>
                                        <li>
                                            <span>Discount</span>
                                            <span>$0.00 USD</span>
                                        </li>
                                        <li>
                                            <span>Cart Total</span>
                                            <span classname="cart-total-amount">$20.98 USD</span>
                                        </li>
                                    </ul>
                                    <div classname="cart-page__buttons">
                                        <div classname="cart-page__buttons-1">
                                            <a classname="thm-btn" href="checkout.html">Update <span
                                                    classname="fas fa-arrow-right"></span> </a>
                                        </div>
                                        <div classname="cart-page__buttons-2">
                                            <a href="checkout.html" classname="thm-btn">
                                                Checkout <span classname="fas fa-arrow-right"></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section classname="newsletter-two">
            <div classname="container">
                <div classname="newsletter-two__inner">
                    <div classname="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div classname="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div classname="newsletter-two__left">
                        <h2 classname="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p classname="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div classname="newsletter-two__right">
                        <form classname="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div classname="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" classname="thm-btn">Subscribe Now <span classname="fas fa-arrow-right"></span>
                            </button>
                            <div classname="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
</>
  )
}

export default Cart