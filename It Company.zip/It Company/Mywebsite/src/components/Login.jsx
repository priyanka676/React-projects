import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import { Link } from 'react-router-dom'


const Login = () => {
  return (
   <>
   <Navbar />
          <section className="page-header">
            <div className="page-header__bg" >
            </div>
            <div className="container about-section" style={{height:"400px"}}>
                <div className="page-header__inner">
                    <h3 className='text-center text-white fw-bolder ' style={{fontSize:"100px"}}>Login</h3>
                    
                </div>
            </div>
        </section>
        <section className="login-one">
            <div className="container">
                <div className="login-one__form">
                    <div className="inner-title text-center">
                        <h2>Login Here</h2>
                    </div>
                    <form id="login-one__form" name="Login-one_form" action="/login" method="post">
                        <div className="row">
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="email" name="email" id="formEmail" placeholder="Email"
                                            required=""  />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                    <div className="input-box">
                                        <input type="text" name="password" id="formPassword"
                                            placeholder="Password..." required=""  />
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-12">
                                <div className="form-group">
                                 <button className="thm-btn" type="submit" data-loading-text="Please wait...">Login Here
                                        <span><i className="icon-right-arrow"></i></span>
                                    </button>
                                </div>
                            </div>
                            <div className="remember-forget">
                                <div className="checked-box1">
                                    <input type="checkbox" name="saveMyInfo" id="saveinfo" checked="" />
                                    <label for="saveinfo">
                                        <span></span>
                                        Remember me
                                    </label>
                                </div>
                                <div className="forget">
                                    <Link to="/login">Forget password?</Link>
                                </div>
                            </div>

                            <div className="create-account text-center">
                                <p>Not registered yet? <Link to="/register">Create an Account</Link></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <Footer />
   </>
  )
}

export default Login