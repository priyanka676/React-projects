import React, { useState } from 'react'
import Navbar from './Navbar'
import Footer from './Footer'

// Get your free access key at https://web3forms.com (enter your Gmail, key arrives by email)
const ACCESS_KEY = 'e420d213-9cfe-49fa-acd3-2da569e1a888'

const sendToWeb3Forms = async (form, extraFields = {}) => {
  const formData = new FormData(form)
  formData.append('access_key', ACCESS_KEY)
  Object.entries(extraFields).forEach(([key, value]) => formData.append(key, value))

  const res = await fetch('https://api.web3forms.com/submit', {
    method: 'POST',
    body: formData,
  })
  return res.json()
}

const Contact = () => {
  const [contactStatus, setContactStatus] = useState('')
  const [contactSending, setContactSending] = useState(false)
  const [newsStatus, setNewsStatus] = useState('')
  const [newsSending, setNewsSending] = useState(false)

  const handleContactSubmit = async (e) => {
    e.preventDefault()
    const form = e.currentTarget
    setContactSending(true)
    setContactStatus('')

    try {
      const data = await sendToWeb3Forms(form)
      if (data.success) {
        setContactStatus('Thank you! Your message has been sent.')
        form.reset()
      } else {
        setContactStatus('Something went wrong. Please try again.')
      }
    } catch (err) {
      setContactStatus('Network error. Please try again.')
    } finally {
      setContactSending(false)
    }
  }

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault()
    const form = e.currentTarget
    setNewsSending(true)
    setNewsStatus('')

    try {
      const data = await sendToWeb3Forms(form, {
        subject: 'New Newsletter Subscription',
        name: 'Newsletter Subscriber',
      })
      if (data.success) {
        setNewsStatus('Subscribed successfully!')
        form.reset()
      } else {
        setNewsStatus('Something went wrong. Please try again.')
      }
    } catch (err) {
      setNewsStatus('Network error. Please try again.')
    } finally {
      setNewsSending(false)
    }
  }

  return (
    <>
      <Navbar />
      <section className="page-header">
        <div className="page-header__bg"></div>
        <div className="container about-section" style={{ height: '400px' }}>
          <div className="page-header__inner">
            <h3 className="text-center text-white fw-bolder" style={{ fontSize: '100px' }}>Contact</h3>
          </div>
        </div>
      </section>

      <section className="contact-info">
        <div className="container">
          <div className="row">
            <div className="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
              <div className="contact-info__single">
                <div className="contact-info__icon">
                  <span className="icon-call"></span>
                </div>
                <p>Contact Us</p>
                <h3><a href="tel:558270575405">+55 827 057 5405</a></h3>
              </div>
            </div>

            <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
              <div className="contact-info__single">
                <div className="contact-info__icon">
                  <span className="icon-email"></span>
                </div>
                <p>Email Us</p>
                <h3><a href="mailto:example@gamil.com">example@gamil.com</a></h3>
              </div>
            </div>

            <div className="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="300ms">
              <div className="contact-info__single">
                <div className="contact-info__icon">
                  <span className="icon-pin"></span>
                </div>
                <p>Our Office Location</p>
                <h3>12 Green Road 05 New Yark</h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="contact-page">
        <div className="container">
          <div className="contact-page__inner">
            <div
              className="contact-page__bg-shape"
              style={{ backgroundImage: "url('images/shapes/contact-page-bg-shape.png')" }}
            ></div>
            <div className="row">
              <div className="col-xl-6">
                <div className="contact-page__left">
                  <iframe
                    title="map"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619%3A0xba03efb7998eef6d!2sCostco+Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd"
                    className="google-map__one"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>

              <div className="col-xl-6">
                <div className="contact-page__right">
                  <h3 className="contact-page__form-title">Get A Free Quote</h3>
                  <form
                    id="contact-form"
                    className="contact-page__form"
                    onSubmit={handleContactSubmit}
                  
                  >
                    {/* Spam protection (hidden honeypot) */}
                    <input type="checkbox" name="botcheck" style={{ display: 'none' }} tabIndex="-1" autoComplete="off" />

                    <div className="row">
                      <div className="col-xl-6 col-lg-6 col-md-6">
                        <div className="contact-page__input-box">
                          <input type="text" name="name" placeholder="Your name" required />
                        </div>
                      </div>
                      <div className="col-xl-6 col-lg-6 col-md-6">
                        <div className="contact-page__input-box">
                          <input type="email" name="email" placeholder="Your Email" required />
                        </div>
                      </div>
                      <div className="col-xl-6 col-lg-6 col-md-6">
                        <div className="contact-page__input-box">
                          <input type="text" placeholder="Mobile" name="phone" required />
                        </div>
                      </div>
                      <div className="col-xl-6 col-lg-6 col-md-6">
                        <div className="contact-page__input-box">
                          <input type="text" placeholder="Subject" name="message" required />
                        </div> <br />
                      </div>
                      <div className="col-xl-12">
                        <div className="contact-page__input-box text-message-box">
                          <textarea name="message" placeholder="Message" required></textarea>
                        </div>
                        <div className="contact-page__btn-box">
                          <button
                            type="submit"
                            className="thm-btn contact-page__btn"
                            disabled={contactSending}
                          >
                            {contactSending ? 'Please wait...' : 'Send A Message'}
                            <span className="fas fa-arrow-right"></span>
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="result text-white fw-bolder pt-3" style={{fontSize:"30px"}}>{contactStatus}</div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="newsletter-two">
        <div className="container">
          <div className="newsletter-two__inner">
            <div
              className="newsletter-two__shape-1"
              style={{ backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')" }}
            ></div>
            <div className="newsletter-two__img-1">
              <img src="images/resources/newsletter-two-img-1.png" alt="" />
            </div>
            <div className="newsletter-two__left">
              <h2 className="newsletter-two__title">Subscribe to Our Newsletter</h2>
              <p className="newsletter-two__text">
                Get the latest SEO tips and software insights straight to your inbox.
              </p>
            </div>
            <div className="newsletter-two__right">
              <form className="newsletter-two__form" onSubmit={handleNewsletterSubmit}>
                <input type="checkbox" name="botcheck" style={{ display: 'none' }} tabIndex="-1" autoComplete="off" />
                <div className="newsletter-two__input">
                  <input type="email" placeholder="Enter email address" name="email" required />
                </div>
                <button type="submit" className="thm-btn" disabled={newsSending}>
                  {newsSending ? 'Please wait...' : 'Subscribe Now'}
                  <span className="fas fa-arrow-right"></span>
                </button>
              </form>
              <div className="result">{newsStatus}</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </>
  )
}

export default Contact
