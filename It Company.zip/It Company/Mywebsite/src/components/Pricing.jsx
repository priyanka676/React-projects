import React from 'react'
import { Link } from 'react-router-dom'


const Pricing = () => {
  return (
  <>
       <section className="page-header">
            <div className="page-header__bg" style={{backgroundImage: "url('images/backgrounds/page-header-bg.jpg')"}}>
            </div>
            <div className="container">
                <div className="page-header__inner">
                    <h3>Pricing</h3>
                    <div className="thm-breadcrumb__inner">
                        <ul className="thm-breadcrumb list-unstyled">
                            <li><a href="index.html">Home</a></li>
                            <li><span className="icon-arrow-angle-pointing-to-right"></span></li>
                            <li>Pricing</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section className="pricing-one">
            <div className="pricing-one__shape-1"></div>
            <div className="pricing-one__shape-2 float-bob-y">
                <img src="images/shapes/pricing-one-shape-2.png" alt="" />
            </div>
            <div className="container">
                <div className="section-title text-center sec-title-animation animation-style1">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">Our Pricing Plan</span>
                    </div>
                    <h2 className="section-title__title title-animation">Popular Pricing <span>Package</span>
                    </h2>
                </div>
                <div className="row">
                   
                    <div className="col-xl-4 col-lg-4 col-md-6 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__price-box">
                                <div className="pricing-one__price-box-shape"
                                    style={{backgroundImage: "url('images/shapes/pricing-one-price-box-shape-1.png')" }}>
                                </div>
                                <span>Basic Plan</span>
                                <h3 className="pricing-one__price">$35.00</h3>
                                <p className="pricing-one__price-sub-title">Get Popular Plan From Us</p>
                            </div>
                            <div className="pricing-one__points-and-btn">
                                <ul className="pricing-one__price-points list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Multi-Language Content</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Programmable Chatbots</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Digital Analysis</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Social Media Marketing</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Technical Support</p>
                                    </li>
                                </ul>
                                <div className="pricing-one__btn-box">
                                    <Link to="/pricing" className="thm-btn">Choose Plan
                                        <span className="fas fa-arrow-right"></span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                    <div className="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__single-shape-1"></div>
                            <div className="pricing-one__price-box">
                                <div className="pricing-one__price-box-shape"
                                    style={{backgroundImage: "url('images/shapes/pricing-one-price-box-shape-1.png')"}}>
                                </div>
                                <div className="pricing-one__recomanded">
                                    <span>Recommended</span>
                                </div>
                                <span>Standard Plan</span>
                                <h3 className="pricing-one__price">$75.00</h3>
                                <p className="pricing-one__price-sub-title">Get Popular Plan From Us</p>
                            </div>
                            <div className="pricing-one__points-and-btn">
                                <ul className="pricing-one__price-points list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Multi-Language Content</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Programmable Chatbots</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Digital Analysis</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Social Media Marketing</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Technical Support</p>
                                    </li>
                                </ul>
                                <div className="pricing-one__btn-box">
                                    <Link to="/pricing"  className="thm-btn">Choose Plan
                                        <span className="fas fa-arrow-right"></span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    <div className="col-xl-4 col-lg-4 col-md-6 wow fadeInRight" data-wow-delay="300ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__price-box">
                                <div className="pricing-one__price-box-shape"
                                    style={{backgroundImage: "url('images/shapes/pricing-one-price-box-shape-1.png')"}}>
                                </div>
                                <span>Premium Plan</span>
                                <h3 className="pricing-one__price">$93.00</h3>
                                <p className="pricing-one__price-sub-title">Get Popular Plan From Us</p>
                            </div>
                            <div className="pricing-one__points-and-btn">
                                <ul className="pricing-one__price-points list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Multi-Language Content</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Programmable Chatbots</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Digital Analysis</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Social Media Marketing</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Technical Support</p>
                                    </li>
                                </ul>
                                <div className="pricing-one__btn-box">
                                    <Link to="/pricing"  className="thm-btn">Choose Plan
                                        <span className="fas fa-arrow-right"></span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                </div>
            </div>
        </section>
       
        <section className="newsletter-two">
            <div className="container">
                <div className="newsletter-two__inner">
                    <div className="newsletter-two__shape-1"
                        style={{backgroundImage: "url('images/shapes/newsletter-two-shape-1.png')"}}></div>
                    <div className="newsletter-two__img-1">
                        <img src="images/resources/newsletter-two-img-1.png" alt="" />
                    </div>
                    <div className="newsletter-two__left">
                        <h2 className="newsletter-two__title">Subcribe to Our Newsletter</h2>
                        <p className="newsletter-two__text">Get the latest SEO tips and software insights straight to your
                            inbox.</p>
                    </div>
                    <div className="newsletter-two__right">
                        <form className="contact-form-validated newsletter-two__form" action="https://dreamlayout.mnsithub.com/html/itzone/main-html/assets/inc/sendemail.php"
                            method="post">
                            <div className="newsletter-two__input">
                                <input type="email" placeholder="Enter email address" name="email" required />
                            </div>
                            <button type="submit" className="thm-btn">Subscribe Now <span className="fas fa-arrow-right"></span>
                            </button>
                            <div className="result"></div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
  </>
  )
}

export default Pricing