
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Home from "./components/Home";
import About from "./components/About";
import Services from "./components/Services";
import Projects from "./components/Projects";
import Blog from "./components/Blog";
import Contact from "./components/Contact";
import Login from "./components/Login";

import "./App.css";

import Register from "./components/Register";
import Cart from "./components/Cart";
import Blogdetails from "./components/Blogdetails";
import BuisnessAnalyst from "./components/BuisnessAnalyst"
import Digitalmarketing from "./components/Digitalmarketing";
import Softwaredevelopment from "./components/Softwaredevelopment";
import Webdevelopment from "./components/Webdevelopment";
import Uiuxdesign from "./components/Uiuxdesign"
import Teamdetails from "./components/Teamdetails";
import Productdesign from "./components/Productdesign";
import Pricing from "./components/Pricing";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Redirect the main URL to Home */}
        <Route path="/" element={<Navigate to="/home" replace />} />

        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/blogdetails" element={<Blogdetails />} />
        <Route path="/analyst" element={<BuisnessAnalyst />} />
        <Route path="/marketing" element={<Digitalmarketing />} />
        <Route  path="/uiux" element={<Uiuxdesign />}/>
        <Route  path="/software" element={<Softwaredevelopment />}/>
        <Route path="/web" element={<Webdevelopment />} />
        <Route path="/teamdetails" element={<Teamdetails />} />
        <Route path="/productdesign" element={<Productdesign />} />
        <Route path="/pricing" element={<Pricing />} />
        {/* Page not found */}
        <Route path="*" element={<h1>404 - Page Not Found</h1>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

