
const navItems = document.querySelectorAll(".nav-item-custom");
navItems.forEach(function (item) {

    item.addEventListener("click", function () {
        navItems.forEach(function (nav) {
            nav.classList.remove("active");
        });
        item.classList.add("active");
        const section = item.getAttribute("data-section");
        console.log("Selected:", section);
     
        if (section !== "Flights") {
            document.getElementById("searchMessage").innerText =
                section + " section selected.";
        } else {
            document.getElementById("searchMessage").innerText = "";
        }

    });

});

const swapBtn = document.getElementById("swapBtn");
const fromCity = document.getElementById("fromCity");
const toCity = document.getElementById("toCity");

swapBtn.addEventListener("click", function () {
    const temp = fromCity.innerText;
    fromCity.innerText = toCity.innerText;
    toCity.innerText = temp;

});

const tripOptions = document.querySelectorAll(
    'input[name="tripType"]'
);
tripOptions.forEach(function (radio) {
    radio.addEventListener("change", function () {
        const selectedTrip = this.value;
        console.log("Trip type:", selectedTrip);
        const returnField =
            document.getElementById("returnField");

        if (selectedTrip === "One Way") {
            returnField.style.opacity = "0.65";
            returnField.querySelector(".return-text").innerHTML =
                "Tap to add a return<br>" +
                "date for bigger<br>" +
                "discounts";

        } else {

            returnField.style.opacity = "1";

            returnField.querySelector(".return-text").innerHTML =
                "Select return date";
        }
    });

});
const fareCards = document.querySelectorAll(".fare-card");
fareCards.forEach(function (card) {
    card.addEventListener("click", function () {
        fareCards.forEach(function (fare) {
            fare.classList.remove("active-fare");
        });
        card.classList.add("active-fare");
        const fareName = card.getAttribute("data-fare");
        console.log("Selected fare:", fareName);
        document.getElementById("searchMessage").innerText =
            fareName + " fare selected.";
        setTimeout(function () {
            document.getElementById("searchMessage").innerText = "";
        }, 2000);
    });

});

const flightTracker =
    document.getElementById("flightTracker");

flightTracker.addEventListener("click", function () {

    document.getElementById("searchMessage").innerText =
        "Flight Tracker selected.";

    setTimeout(function () {

        document.getElementById("searchMessage").innerText = "";

    }, 2500);

});
const searchButton =
    document.getElementById("searchButton");
searchButton.addEventListener("click", function () {

    const from =
        fromCity.innerText.trim();

    const to =
        toCity.innerText.trim();

    const trip =
        document.querySelector(
            'input[name="tripType"]:checked'
        ).value;

    const fare =
        document.querySelector(
            ".fare-card.active-fare"
        ).getAttribute("data-fare");
    if (from === "" || to === "") {

        document.getElementById("searchMessage").innerText =
            "Please enter From and To locations.";

        return;
    }
    document.getElementById("searchMessage").innerText =
        "Searching flights from " +
        from +
        " to " +
        to +
        " • " +
        trip +
        " • " +
        fare;
    console.log({
        from: from,
        to: to,
        trip: trip,
        fare: fare
    });

});

fromCity.addEventListener("input", function () {

    console.log("From:", this.innerText);

});
toCity.addEventListener("input", function () {

    console.log("To:", this.innerText);

});


fromCity.addEventListener("blur", function () {
    if (this.innerText.trim() === "") {

        this.innerText = "New Delhi";
    }

});
toCity.addEventListener("blur", function () {

    if (this.innerText.trim() === "") {

        this.innerText = "Bengaluru";
    }
});