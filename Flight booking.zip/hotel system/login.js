const toggle = document.getElementById('pwToggle');
const pwInput = document.getElementById('password');
const eyeIcon = document.getElementById('eyeIcon');

const eyeOpen = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
const eyeOff  = `<line x1="1" y1="1" x2="23" y2="23"/><path d="M10.58 10.58A3 3 0 0 0 14.99 15M9.9 4.24A10 10 0 0 1 12 4c7 0 11 8 11 8a19.5 19.5 0 0 1-2.9 3.9M6.61 6.61A13.5 13.5 0 0 0 1 12s4 8 11 8a10 10 0 0 0 5.39-1.61"/>`;

toggle.addEventListener('click', () => {
  const isHidden = pwInput.type === 'password';
  pwInput.type = isHidden ? 'text' : 'password';
  eyeIcon.innerHTML = isHidden ? eyeOff : eyeOpen;
});