import './App.css'
import { BrowserRouter, Route } from 'react-router-dom'

import AnimatedRoutes from './components/AnimatedRoutes'

function App() {
  return (
    <BrowserRouter>

      <AnimatedRoutes />
    </BrowserRouter>
  )
}

export default App
