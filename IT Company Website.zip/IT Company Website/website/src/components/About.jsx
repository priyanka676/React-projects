
import React from "react";
import Aboutlayout from "./Aboutlayout";
import Footer from "./Footer";


const About = () => {
  const experts = [
    {
      id: 1,
      name: "Edward Eric Jr",
      designation: "Business & Financial Expert",
      image: "/images/resource/team-1.jpg",
    },
    {
      id: 2,
      name: "Tom Holland",
      designation: "Logistic & Communication Expert",
      image: "/images/resource/team-2.jpg",
    },
    {
      id: 3,
      name: "Laura Erakovic",
      designation: "Consumer Market Expert",
      image: "/images/resource/team-3.jpg",
    },
  ];

  const testimonials = [
    {
      id: 1,
      name: "Ryan Betthalyn",
      company: "Director at Chobham Manor",
    },
    {
      id: 2,
      name: "Bobs Hanley",
      company: "Director at Spotify",
    },
    {
      id: 3,
      name: "Ryan Betthalyn",
      company: "Director at Chobham Manor",
    },
    {
      id: 4,
      name: "Bobs Hanley",
      company: "Director at Spotify",
    },
  ];

  const clients = [
    "/images/clients/1.png",
    "/images/clients/2.png",
    "/images/clients/3.png",
    "/images/clients/4.png",
    "/images/clients/5.png",
    "/images/clients/1.png",
    "/images/clients/2.png",
    "/images/clients/3.png",
  ];

  return (
    <>
    <Aboutlayout />
    <section>

      <div className="page-banner-image-section">
        <div className="image">
          <img
            src="/images/background/1.jpg"
            alt="Page Banner"
            className="img-fluid w-100"
          />
        </div>
      </div>

  
      <section id="about" className="py-5">
        <div className="container py-5">
          <div className="row align-items-center">
            <div className="col-lg-6 mb-4 mb-lg-0">
              <img
                src="/images/about/home-about.png"
                alt="About Consulte"
                className="img-fluid"
              />
            </div>

            <div className="col-lg-6">
              <div className="text-uppercase text mb-2">
                About Consulte
              </div>

              <h2 className="display-6 fw-bold">
                 <span className="text">About company</span>
                <br />
              </h2>

              <p className="paragraph">
              we turn complex technology into simple, reliable solutions. 
              With 25+ years of experience and a team of certified experts.
             
              </p>

              <p className="paragraph">
              we help startups, SMEs, and enterprises modernize their operations, protect their data, 
              and deliver better digital experiences to their customers.
              </p>
              <a href="#about" className="btn btn-success mt-3 px-4 py-3">
                  Work With Us
                </a>
            </div>
          </div>
        </div>
      </section>
     
      <div className="reputation-section-two py-5">
        <div className="auto-container container">
          <div className="row align-items-center">

            <div className="content-column col-lg-7 col-md-12">
              <div className="inner-column">

                <div className="sec-title mb-4">
                  <div className="title">WHY CHOOSE US</div>

                  <h2>
                    <span>Your Successful</span>
                    <br />
                    Is Our Reputation
                  </h2>
                </div>

                <div className="blocks-outer">

                  <div className="reputation-block mb-4">
                    <div className="inner-box">
                      <h5>Strong Market Analysis</h5>

                      <div className="text">
                        Tasks, docs, and files integrate with Arado’s chat
                        to close the gaps between feedback and action.
                      </div>
                    </div>
                  </div>

                  <div className="reputation-block mb-4">
                    <div className="inner-box">
                      <h5>Experience & Precision</h5>

                      <div className="text">
                        Create multiple discussions to keep all relevant
                        conversations together, all in one place with Arado.
                      </div>
                    </div>
                  </div>

                  <div className="reputation-block mb-4">
                    <div className="inner-box">
                      <h5>Experts About Business</h5>

                      <div className="text">
                        Create multiple discussions to keep all relevant
                        conversations together, all in one place with Arado.
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

         
            <div className="form-column col-lg-5 col-md-12">
              <div className="inner-column">
                <div className="form-boxed p-4 shadow-sm">

                  <h5>SEND MESSAGE</h5>

                  <div className="consult-form">
                    <form
                      method="post"
                      action="https://htmldemo.net/consultix/consultix/donate.html"
                    >

                      <div className="form-group mb-3">
                        <label className="d-block mb-2">
                          Full Name
                        </label>

                        <input
                          type="text"
                          name="name"
                          className="form-control"
                          placeholder="Jason Staham"
                          required
                        />
                      </div>

                      <div className="form-group mb-3">
                        <label className="d-block mb-2">
                          Phone Number
                        </label>

                        <input
                          type="text"
                          name="phone"
                          className="form-control"
                          placeholder="Enter your phone number"
                          required
                        />
                      </div>

                      <div className="form-group mb-3">
                        <label className="d-block mb-2">
                          Topics
                        </label>

                        <select
                          name="topic"
                          className="form-select"
                          defaultValue=""
                        >
                          <option value="" disabled>
                            Choose topic
                          </option>
                          <option value="topic-01">Topic 01</option>
                          <option value="topic-02">Topic 02</option>
                          <option value="topic-03">Topic 03</option>
                          <option value="topic-04">Topic 04</option>
                        </select>
                      </div>

                      <div className="form-group mb-3">
                        <label className="d-block mb-2">
                          Message
                        </label>

                        <textarea
                          name="message"
                          className="form-control"
                          rows="5"
                          placeholder="Write your message here"
                        ></textarea>
                      </div>

                      <div className="form-group">
                        <button
                          className="theme-btn btn-style-one  text-white"
                          type="submit"
                          name="submit-form"
                        >
                          Send Your Message
                        </button>
                      </div>

                    </form>
                  </div>

                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

   
      <div className="experts-section py-5">
        <div className="auto-container container">

          <div className="sec-title mb-5">
            <div className="d-flex justify-content-between align-items-center flex-wrap">

              <div>
                <div className="title">OUR SERVICES</div>

                <h2>
                  We Are{" "}
                  <span>IT Professional</span>
                </h2>
              </div>

              <div>
                <a href="/service" className="experts">
                  All Experts <span className="arrow">→</span>
                </a>
              </div>

            </div>
          </div>

          <div className="row">

            {experts.map((expert) => (
              <div
                className="team-block col-lg-4 col-md-6 col-sm-6 col-12 mb-4"
                key={expert.id}
              >
                <div className="inner-box">

                  <div className="image">
                    <a href="#">
                      <img
                        src={expert.image}
                        alt={expert.name}
                        className="img-fluid w-100"
                      />
                    </a>

                    <ul className="social-box list-unstyled d-flex gap-3 mt-3">
                      <li>
                        <a
                          href="https://twitter.com/"
                          target="_blank"
                          rel="noreferrer"
                        >
                          Twitter
                        </a>
                      </li>

                      <li>
                        <a
                          href="https://facebook.com/"
                          target="_blank"
                          rel="noreferrer"
                        >
                          Facebook
                        </a>
                      </li>

                      <li>
                        <a
                          href="https://www.instagram.com/"
                          target="_blank"
                          rel="noreferrer"
                        >
                          Instagram
                        </a>
                      </li>

                      <li>
                        <a
                          href="https://www.linkedin.com/"
                          target="_blank"
                          rel="noreferrer"
                        >
                          LinkedIn
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div className="lower-box mt-3">
                    <h4>
                      <a href="#">{expert.name}</a>
                    </h4>

                    <div className="designation">
                      {expert.designation}
                    </div>
                  </div>

                </div>
              </div>
            ))}

          </div>
        </div>
      </div>

    
      <div className="testimonial-section style-two py-5">
        <div className="auto-container container">

          <div className="inner-container">

            <div className="sec-title mb-4">
              <div className="title">TESTIMONIALS</div>

              <h2>
                <span>+2,500 Clients</span> Love Us
              </h2>
            </div>

            <div className="row">

              {testimonials.map((testimonial) => (
                <div
                  className="testimonial-block col-lg-6 mb-4"
                  key={testimonial.id}
                >
                  <div className="inner-box p-4 shadow-sm">

                    <div className="quote fs-2 mb-2">
                      ❝
                    </div>

                    <div className="author fw-bold">
                      {testimonial.name}{" "}
                      <span className="fw-normal">
                        / {testimonial.company}
                      </span>
                    </div>

                    <div className="text mt-3">
                      Sed elit quam, iaculis sed semper sit amet
                      udin vitae nibh. Rubino at magna akal semper.
                      Fusce commodo molestie luctus. Lorem ipsum
                      dolor tusima olatiup.
                    </div>

                  </div>
                </div>
              ))}

            </div>

          </div>
        </div>
      </div>

     

    </section>
  
   <Footer />
    </>
  );
};

export default About;

