import React from 'react'

const Footer = () => {
  return (
    <section>
          <footer className="main-footer style-two">
		<div className="auto-container">
        	
            <div className="widgets-section">
            	<div className="row clearfix">
                	
                   
                    <div className="big-column col-lg-6 col-md-12 col-sm-6 col-12">
						<div className="row clearfix">
						
                        	
                            <div className="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div className="footer-widget logo-widget">
									<div className="logo">
										<a href="index.html"><img src="images/logo.png" alt="" /></a>
									</div>
									<div className="call">
										Call us directly
										<a className="phone" href="tel:+1-212-226-3126">+1 212-226-3126</a>
										<a className="email" href="mailto:hello@consulte.co">hello@consulte.co</a>
									</div>
								</div>
							</div>
							
							
                            <div className="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div className="footer-widget links-widget">
									<h5>Company</h5>
									<ul className="list-link">
										<li><a href="#">About Us</a></li>
										<li><a href="#">Team</a></li>
										<li><a href="#">Careers</a></li>
										<li><a href="#">Investors</a></li>
										<li><a href="#">Contact Us</a></li>
										<li><a href="#">Offices</a></li>
									</ul>
								</div>
							</div>
							
						</div>
					</div>
					
					
                    <div className="big-column col-lg-6 col-md-12 col-sm-6 col-12">
						<div className="row clearfix">
							
							
                            <div className="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div className="footer-widget links-widget">
									<h5>Quick Links</h5>
									<ul className="list-link">
										<li><a href="#">FAQS</a></li>
										<li><a href="#">Support</a></li>
										<li><a href="#">Sitemap</a></li>
										<li><a href="#">Community</a></li>
									</ul>
								</div>
							</div>
							
							
                            <div className="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div className="footer-widget newsletter-widget">
									<h5>Our Newsletter</h5>
									<div className="text">Subscribe to our newsletter and we will inform you about latest updates and offers</div>
								
									<div className="newsletter-form">
										<form method="post" action="https://htmldemo.net/consultix/consultix/contact.html">
											<div className="form-group">
												<input type="email" name="email" value="" placeholder="Email Address..." required />
												<button type="submit" className="theme-btn icofont-arrow-right"></button>
											</div>
										</form>
									</div>
								</div>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
			
			
			<div className="footer-bottom">
				<div className="auto-container">
					<div className="bottom-inner">
						<div className="row clearfix">
							
							<div className="col-lg-8 col-md-12 col-sm-12">
								<div className="copyright">Copyright ©<script async="" src="../../../www.google-analytics.com/analytics.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i className="icon-heart text-danger" aria-hidden="true"></i> by <a href="https://hasthemes.com/" target="_blank">HasThemes</a></div>
							</div>
							
							<div className="col-lg-4 col-md-12 col-sm-12">
								<ul className="social-nav">
									<li><a href="https://twitter.com/" className="icofont-twitter"></a></li>
									<li><a href="http://facebook.com/" className="icofont-facebook"></a></li>
									<li><a href="https://www.instagram.com/" className="icofont-instagram"></a></li>
									<li><a href="https://rss.com/" className="icofont-rss"></a></li>
									<li><a href="https://www.youtube.com/" className="icofont-play-alt-1"></a></li>
								</ul>
							</div>
							
						</div>
					</div>
				</div>	
			</div>
			
		</div>
	</footer>
    </section>
  )
}

export default Footer