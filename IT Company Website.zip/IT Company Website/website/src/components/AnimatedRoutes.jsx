import { useEffect, useRef } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Home from './Home'
import About from './About'
import Service from './Service'
import Servicedetail from './Servicedetail'
import Project from './Project'
import Blog from './Blog'
import Blogdetails from './Blogdetails'
import Contact from './Contact'
import MyLayout from '../pages/MyLayout'
import { initReveal } from '../animations/reveal'
import '../animations/animations.css'

// Thin bar at the top of the screen showing how far the page is scrolled.
function ScrollProgress() {
  const barRef = useRef(null)

  useEffect(() => {
    let frame = 0
    const update = () => {
      frame = 0
      const max = document.documentElement.scrollHeight - window.innerHeight
      const ratio = max > 0 ? window.scrollY / max : 0
      if (barRef.current) {
        barRef.current.style.transform = `scaleX(${Math.min(Math.max(ratio, 0), 1)})`
      }
    }
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [])

  return <div className="scroll-progress" ref={barRef} aria-hidden="true" />
}

function AnimatedRoutes() {
  const location = useLocation()

  // On every page change: jump to top and start the scroll-reveal animations.
  useEffect(() => {
    window.scrollTo(0, 0)
    return initReveal(document.getElementById('root'))
  }, [location.pathname])

  return (
    <>
      <ScrollProgress />
      {/* key = pathname, so the fade-in replays on each page */}
      <div className="page-transition" key={location.pathname}>
        <Routes location={location}>
          <Route path="/" element={<Home />} />
          <Route path="home" element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="project" element={<Project />} />
          <Route path="service" element={<Service />} />
          <Route path="servicedetail" element={<Servicedetail />} />
          <Route path="blog" element={<Blog />} />
          <Route path="blogdetails" element={<Blogdetails />} />
          <Route path="contact" element={<Contact />} />
        </Routes>
      </div>
    </>
  )
}

export default AnimatedRoutes
