import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
 <>
  <header className="main-header">
    	
        <div className="header-top">
            <div className="auto-container">
                <div className="inner-container clearfix">
					
					<div className="top-left">
					
						<ul className="info-list">
							<li><a href="mailto:hello@consulte.co"><span className="icon icofont-envelope"></span> hello@consulte.co</a></li>
							<li><a href="tel:+1212-226-3126"><span className="icon icofont-phone"></span> +1212-226-3126</a></li>
							<li><a href="contact.html"><span className="icon icofont-clock-time"></span> Mon - Sat: 8.00 - 17.00, Sunday Closed</a></li>
						</ul>
					</div>
					
				
                    <div className="top-right pull-right">
						
						<ul className="social-box">
							<li className="share">Our Social</li>
							<li><a href="https://twitter.com/" className="icofont-twitter"></a></li>
							<li><a href="http://facebook.com/" className="icofont-facebook"></a></li>
							<li><a href="https://www.instagram.com/" className="icofont-instagram"></a></li>
							<li><a href="https://rss.com/" className="icofont-rss"></a></li>
							<li><a href="https://www.youtube.com/" className="icofont-play-alt-1"></a></li>
						</ul>
                    </div>
					
                </div>
            </div>
        </div>
		
    	
        <div className="header-upper">
        	<div className="auto-container">
            	<div className="inner-container clearfix">
                	
                	<div className="pull-left logo-box">
                    	<div className="logo"><a href="index.html">
                            <img src="images/logo.png" alt="" title="" /></a></div>
                    </div>
					
                   	<div className="nav-outer pull-left clearfix">
					
						<nav className="main-menu navbar-expand-md">
							<div className="navbar-header">
								<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<span className="icon-bar"></span>
									<span className="icon-bar"></span>
									<span className="icon-bar"></span>
								</button>
							</div>

							<div className="navbar-collapse show collapse clearfix" id="navbarSupportedContent">
								<ul className="navigation clearfix">
									<li className="current">
										<Link to="/home">Home</Link></li>
									<li>
										<Link to="/about">About</Link></li>
									<li className="dropdown">
										<Link to="/service">Service</Link>
										<ul>
											<li>
												<Link to="/service">Service</Link></li>
											<li>
												<Link to="service-detail.html">Service Detail</Link></li>
										</ul>
									</li>
									<li className="dropdown">
										<Link to="/project">Projects</Link>
										<ul>
											<li>
												<Link to="/project">Project</Link></li>
											<li>
												<a href="project-details.html">Project Details</a></li>
										</ul>
									</li>
									<li className="dropdown">
										<Link to="/blog">Blog</Link>
										<ul className="from-right">
											<li>
												<Link to="/blog">Our Blog</Link></li>
											<li>
												<Link to="blog-detail.html">Blog Detail</Link></li>
										</ul>
									</li>
									<li>
										<Link to="/contact">Contact</Link></li>
								</ul>
							
							</div>
							
						</nav>
						
					</div>
					
					
					<div className="outer-box">
					
						<div className="search-box-btn search-box-outer">
                            <span className="icon icofont-search"></span></div>
						
                        <div className="mobile-nav-toggler">
                            <span className="icon ti-menu"></span></div>
					</div>
                   
                </div>
            </div>
        </div>
     
        
	
        <div className="mobile-menu">
            <div className="menu-backdrop"></div>
            <div className="close-btn"><span className="icon lnr lnr-cross"></span></div>
            
            <nav className="menu-box">
                <div className="nav-logo"><a href="index.html">
                    <img src="images/logo.png" alt="" title="" /></a></div>
                <div className="menu-outer"></div>
            </nav>
        </div>
		
    </header>
 </>
  )
}

export default Navbar