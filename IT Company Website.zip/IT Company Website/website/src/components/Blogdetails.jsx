import React from "react";
import Aboutlayout from "./Aboutlayout";
import Footer from './Footer'


const Blogdetails = () => {
  const handleSearch = (e) => {
    e.preventDefault();
  
  };

  const handleComment = (e) => {
    e.preventDefault();
    // TODO: send the comment to your API here
  };

  return (
    <>
    <Aboutlayout />
    <section>
      <div className="page-title-section style-two">
        <div className="auto-container">
          <ul className="post-meta">
            <li><a href="/">Index</a></li>
            <li>Blog</li>
          </ul>
          <h2>
            Problems About Social Insurance For <br /> Truck Drivers
          </h2>
        </div>
      </div>

      <div className="sidebar-page-container padding-top style-two">
        <div className="auto-container">
          <div className="row clearfix">
            {/* Content Side */}
            <div className="content-side col-lg-9 col-md-12 col-sm-12">
              <div className="blog-detail">
                <div className="inner-box">
                  <div className="image">
                    <img src="/images/resource/news-9.jpg" alt="" />
                  </div>
                  <div className="lower-content">
                    <div className="post-info">
                      <span className="theme_color">business</span> - December 14th, 2020 by <i>Admin</i>
                    </div>
                    <p>
                      Most times, ideacide happens without us even realizing it. A possible off-the-wall idea or
                      solution appears like a blip and disappears without us even realizing. As a result, some of our
                      best stuff is suppressed before even getting out into the world. Whether it’s because we’re too
                      critical or because we recoil at the impending pain of change, the disruption of normalcy,
                      self-censoring arises out of fear. Welsh novelist Sarah Waters sums it up eloquently: “Midway
                      through writing a novel, I have regularly experienced moments of bowel-curdling terror, as I
                      contemplate the drivel on the screen before me and see beyond it, in quick succession, the
                      derisive reviews, the friends’ embarrassment, the failing career, the dwindling income, the
                      repossessed house, the divorce…” We know self-censoring by many names. Carl Jung called it our
                      “inner critic.” Michael Ray and Rochelle Myers called it the “voice of judgment” in their classic
                      book, in Business, based on a popular course they co-taught at Stanford University the derisive
                      reviews, the friends’ embarrassment, the failing career, the dwindling income, the repossessed
                    </p>
                    <div className="middle-image">
                      <img src="/images/resource/news-10.jpg" alt="" />
                    </div>
                    <h4>Gathered Was Isn’t Fruitful Every</h4>
                    <p>
                      Give void had the creature man evening two be for heaven won’t you’re may. Subdue him. Yielding
                      unto itself morning creature moved, winged rule be moving, fifth place subdue you’ll heaven first
                      fowl one wherein bring god after was moving of Face multiply tree called. Subdue first said made
                      living tree you’re two beast, moved, every. Evening their us seas.
                    </p>

                    <blockquote>
                      <div className="blockquote-text">
                        <span className="quote icofont-quote-left"></span>
                        Our greatest weakness lies in giving up. <br />
                        The most certain way to succeed is always to <br />
                        try just one more time.
                      </div>
                    </blockquote>

                    <p>
                      Both of these assumptions, of course, could be entirely false. Self-censoring is firmly rooted
                      in our experiences with mistakes in the past and not the present. The brain messages arising
                      from those experiences can be deceptive.
                    </p>

                    <div className="post-share-options">
                      <div className="tags">
                        <a href="#">Structure</a> <a href="#">Envato</a> <a href="#">Premium</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Related Posts */}
              <div className="related-projects">
                <div className="title-box">
                  <h3>Related Posts</h3>
                </div>
                <div className="row clearfix">
                  <div className="news-block-four col-lg-6 col-md-6 col-sm-12">
                    <div className="inner-box">
                      <div className="image">
                        <a href="/blog-detail">
                          <img src="/images/resource/news-4.jpg" alt="" />
                        </a>
                      </div>
                      <div className="lower-content">
                        <div className="title">business</div>
                        <h4><a href="/blog-detail">Problems About Social Insurance For Truck Drivers</a></h4>
                      </div>
                    </div>
                  </div>

                  <div className="news-block-four col-lg-6 col-md-6 col-sm-12">
                    <div className="inner-box">
                      <div className="image">
                        <a href="/blog-detail">
                          <img src="/images/resource/news-5.jpg" alt="" />
                        </a>
                      </div>
                      <div className="lower-content">
                        <div className="title">News</div>
                        <h4><a href="/blog-detail">5 Steps To Build Strategy Planning</a></h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar Side */}
            <div className="sidebar-side col-lg-3 col-md-12 col-sm-12">
              <aside className="sidebar sticky-top margin-left">
                {/* Search */}
                <div className="sidebar-widget search-box">
                  <div className="sidebar-title">
                    <h4>Search</h4>
                  </div>
                  <form onSubmit={handleSearch}>
                    <div className="form-group">
                      <input type="search" name="search-field" defaultValue="" placeholder="Type & Hit Enter..." required />
                      <button type="submit"><span className="icon fa fa-search"></span></button>
                    </div>
                  </form>
                </div>

                {/* Categories */}
                <div className="sidebar-widget categories-blog">
                  <div className="sidebar-title">
                    <h4>Categories</h4>
                  </div>
                  <ul>
                    <li><a href="#">All <span>25</span></a></li>
                    <li><a href="#">News <span>12</span></a></li>
                    <li><a href="#">business <span>7</span></a></li>
                    <li><a href="#">tips &amp; tricks <span>4</span></a></li>
                    <li><a href="#">Others <span>2</span></a></li>
                  </ul>
                </div>

                {/* Recent Posts */}
                <div className="sidebar-widget popular-posts">
                  <div className="sidebar-title">
                    <h4>Recent Posts</h4>
                  </div>
                  <div className="widget-content">
                    <div className="post">
                      <figure className="post-thumb">
                        <a href="/blog-detail"><img src="/images/resource/post-thumb-1.jpg" alt="" /></a>
                      </figure>
                      <div className="text"><a href="/blog-detail">5 Secrets To Coaching Your Employees To Greatness</a></div>
                    </div>

                    <div className="post">
                      <figure className="post-thumb">
                        <a href="/blog-detail"><img src="/images/resource/post-thumb-2.jpg" alt="" /></a>
                      </figure>
                      <div className="text"><a href="/blog-detail">5 Steps To Build Strategy Planning</a></div>
                    </div>

                    <div className="post">
                      <figure className="post-thumb">
                        <a href="/blog-detail"><img src="/images/resource/post-thumb-3.jpg" alt="" /></a>
                      </figure>
                      <div className="text"><a href="/blog-detail">Trend Of Consumer Market 2020</a></div>
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div className="sidebar-widget tags">
                  <div className="sidebar-title">
                    <h4>Tags</h4>
                  </div>
                  <div className="widget-content">
                    <a href="#">Structure</a>
                    <a href="#">Envato</a>
                    <a href="#">Premium</a>
                    <a href="#">Clean</a>
                    <a href="#">WordPress</a>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </div>

        {/* Comment Form */}
        <div className="lower-section">
          <div className="auto-container">
            <div className="comment-form">
              <div className="group-title">
                <h3>Leave A Reply</h3>
                <div className="comment-text">Your email address will not be published</div>
              </div>

              <form onSubmit={handleComment}>
                <div className="row clearfix">
                  <div className="col-md-12 col-sm-12 col-xs-12 form-group">
                    <input type="text" name="username" placeholder="Name *" required />
                  </div>

                  <div className="col-md-6 col-sm-12 col-xs-12 form-group">
                    <input type="email" name="email" placeholder="Email Address *" required />
                  </div>

                  <div className="col-md-6 col-sm-12 col-xs-12 form-group">
                    <input type="text" name="subject" placeholder="Subject (Optional)" />
                  </div>

                  <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
                    <textarea name="message" placeholder="Message"></textarea>
                  </div>

                  <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
                    <button className="theme-btn btn-style-one" type="submit" name="submit-form">
                      <span className="txt">Post Comment</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
    <Footer />
    </>
  );
};

export default Blogdetails;
