
import React from "react";
import Navbar from "./Navbar";
import Aboutlayout from "./Aboutlayout";
import Footer from "./Footer";

const Home = () => {
  const services = [
    {
      icon: "⚛️",
      title: "React",
      text: "Build fast, interactive web interfaces with reusable components. Ideal for dashboards, web apps, and single-page applications.",
    },
    {
      icon: "💹",
      title: "Python",
      text: "Powerful and versatile development for web backends, automation, data analysis, and AI-driven solutions.",
    },
    {
      icon: "🛡️",
      title: "Android",
      text: "Native Android apps built for performance, smooth user experience, and reach across millions of devices.",
    },
    {
      icon: "☕",
      title: "Java",
      text: "Secure, scalable enterprise applications and robust backend systems built for long-term reliability.",
    },
    {
      icon: "🐘",
      title: "Php",
      text: "Dynamic websites and web applications, including Laravel-based solutions, delivered quickly and cost-effectively.",
    },
    {
      icon: "💰",
      title: "Flutter",
      text: "One codebase for Android and iOS. Beautiful, high-performance cross-platform apps with faster delivery.",
    },
    {
      icon: "📝",
      title: "WordPress",
      text: "Custom themes, plugins, and fully manageable websites for businesses, blogs, and online stores.",
    },
    {
      icon: "🎨",
      title: "UI UX Design",
      text: "User-focused design that combines clean visuals with intuitive navigation to improve engagement and conversions.",
    },
  ];

  const projects = [
    {
      image: "/images/image2.jpg",
      title: "TechNova",
      category: "IT Solutions & Services",
    },
    {
      image: "/images/image3.jpg",
      title: "TechVision",
      category: "Digital Innovation",
    },
    {
      image: "/images/myimage3.jpg",
      title: "Nexora Technologies",
      category: "IT Services & Consulting",
    },
    {
      image: "/images/myimage4.jpg",
      title: "TechBridge",
      category: "Connecting Business Through Technology",
    },
  ];

  const testimonials = [
    {
      name: "Ryan Betthalyn",
      company: "Director at Chobham Manor",
      text: "Sed elit quam, iaculis sed semper sit amet vitae nibh. Rubino at magna semper. Fusce commodo molestie luctus.",
    },
    {
      name: "Bobs Hanley",
      company: "Director at Spotify",
      text: "Sed elit quam, iaculis sed semper sit amet vitae nibh. Rubino at magna semper. Fusce commodo molestie luctus.",
    },
    {
      name: "Ryan Betthalyn",
      company: "Director at Chobham Manor",
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce commodo molestie luctus.",
    },
  ];

  const team = [
    {
      image: "/images/team1.jpg",
      name: "Edward Eric Jr",
      designation: "Business & Financial Expert",
    },
    {
      image: "/images/team2.jpg",
      name: "Tom Holland",
      designation: "Logistic & Communication Expert",
    },
    {
      image: "/images/team3.jpg",
      name: "Laura Erakovic",
      designation: "Consumer Market Expert",
    },
  ];

  const blogs = [
    {
      image: "/images/myimag1.jpg",
      category: "Business",
      title: "Problems About Social Insurance For Truck Drivers",
    },
    {
      image: "/images/myimage4.jpg",
      category: "Bank & Finance",
      title: "Payment Online - Things That You Know To Project Your Money",
    },
    {
      image: "/images/myimage3.jpg",
      category: "Tips & Tricks",
      title: "5 Secrets To Coaching Your Employees To Greatness",
    },
  ];

  return (
    <>
<Aboutlayout />
      <section
        className="banner-section"
        style={{
          backgroundImage: "url('/images/main-slider/intro-1.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          minHeight: "650px",
          display: "flex",
          alignItems: "center",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-lg-7 col-md-12">
              <div className="py-5">
                <div className="text-uppercase mb-3">
                  It Company
                </div>
               
                <h1 className="fw-bold text-black">
                Smart <span className="text"> IT Solutions</span> for a
                <br />
                <span className="text">  Digital</span> First World
                 
                </h1>

                <p className="lead mt-4 text-black">
                We design, build, and manage IT solutions that help businesses grow faster, work smarter, and stay secure.
                </p>

                <a href="#about" className="btn btn-success mt-3 px-4 py-3">
                  Work With Us
                </a>
              </div>
            </div>
            <div className="col-lg-5">
              <img src="images/about/home.png" width="" height="" />

            </div>

          </div>
        </div>
      </section>



      <section id="about" className="py-5">
        <div className="container py-5">
          <div className="row align-items-center">
            <div className="col-lg-6 mb-4 mb-lg-0">
              <img
                src="/images/about/home-about.png"
                alt="About Consulte"
                className="img-fluid"
              />
            </div>

            <div className="col-lg-6">
              <div className="text-uppercase text mb-2">
                About Consulte
              </div>

              <h2 className="display-6 fw-bold">
                 <span className="text">About company</span>
                <br />
              </h2>

              <p className="paragraph">
              we turn complex technology into simple, reliable solutions. 
              With 25+ years of experience and a team of certified experts.
             
              </p>

              <p className="paragraph">
              we help startups, SMEs, and enterprises modernize their operations, protect their data, 
              and deliver better digital experiences to their customers.
              </p>
              <a href="#about" className="btn btn-success mt-3 px-4 py-3">
                  Work With Us
                </a>
            </div>
          </div>
        </div>
      </section>


      <section className="py-5 bg-light">
        <div className="container py-5">
          <div className="text-center mb-5">
            <div className="text-black text-uppercase">
              Our Services
            </div>

            <h2 className="fw-bold text-black">
              <span className="text">Technologies</span> 
            </h2>
          </div>

          <div className="row g-4">
            {services.map((service, index) => (
              <div
                className="col-lg-3 col-md-6"
                key={index}
              >
                <div className="card h-100 border-0 shadow-sm p-4 text-center">
                  <div className="fs-1 mb-3">{service.icon}</div>

                  <h5 className="fw-bold text" style={{fontSize:"30px"}}>{service.title}</h5>

                  <p className="text-muted">
                    {service.text}
                  </p>

                  <a href="#services" className="text-primary text-decoration-none">
                    More →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      <section className="py-5">
        <div className="container py-5">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <div className="text-black text-uppercase">
                Latest Projects
              </div>

              <h2 className="fw-bold text-black">
                See Our{" "}
                <span className="text">
                 Latest Projects
                </span>
              </h2>
            </div>

            <a href="#projects" className="text-primary">
              All Cases →
            </a>
          </div>

          <div className="row g-4">
            {projects.map((project, index) => (
              <div className="col-lg-6" key={index}>
                <div className="card border-0 shadow overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="img-fluid"
                    style={{
                      width: "100%",
                      height: "300px",
                      objectFit: "cover",
                    }}
                  />

                  <div className="card-body">
                    <h4>{project.title}</h4>
                    <p className="text-muted mb-0">
                      {project.category}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      <section className="py-5 bg-light">
        <div className="container py-5">
          <div className="text-center mb-5">
            <div className="text text-uppercase text-black">
              Testimonials
            </div>

            <h2 className="fw-bold text-black">
              <span className="text">+2,500 Clients</span> Love Us
            </h2>
          </div>

          <div className="row g-4">
            {testimonials.map((item, index) => (
              <div className="col-lg-4" key={index}>
                <div className="card border-0 shadow-sm h-100 p-4">
                  <div className="fs-1 text">"</div>

                  <p>{item.text}</p>

                  <h5 className="mb-0">{item.name}</h5>

                  <small className="text-muted">
                    {item.company}
                  </small>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>


      


      <section className="py-5 bg-light">
        <div className="container py-5">
          <div className="row">
            <div className="col-lg-5 mb-4 mb-lg-0">
              <div className="card border-0 shadow-sm p-4">
                <h5 className="text-uppercase mb-4">
               contact us
                </h5>

                <form>
                  <div className="mb-3">
                    <label className="form-label">Full Name</label>

                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      placeholder="Jason Staham"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">
                      Phone Number
                    </label>

                    <input
                      type="text"
                      name="phone"
                      className="form-control"
                      placeholder="Enter your phone number"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Topics</label>

                    <select
                      className="form-select"
                      defaultValue=""
                    >
                      <option value="" disabled>
                        Choose topic
                      </option>
                      <option value="1">Topic 01</option>
                      <option value="2">Topic 02</option>
                      <option value="3">Topic 03</option>
                      <option value="4">Topic 04</option>
                    </select>
                  </div>

                  <div className="mb-3">
                    <label className="form-label">Message</label>

                    <textarea
                      name="message"
                      className="form-control"
                      rows="5"
                      placeholder="Write your message here"
                    ></textarea>
                  </div>

                  <button
                    className="btn btn-success w-100"
                    type="submit"
                  >
                    Send Your Message
                  </button>
                </form>
              </div>
            </div>

            <div className="col-lg-7">
              <div className="ps-lg-4">
                <div className="text-black text-uppercase">
                  Why Choose Us
                </div>

                <h2 className="fw-bold mb-4 text-black">
                  <span className="text">
                    Your Successful
                  </span>{" "}
                  Is Our Reputation
                </h2>

                <div className="mb-4">
                  <h5 className="text-black fw-bold">Strong Market Analysis</h5>

                  <p className="text-muted">
                    Tasks, docs, and files integrate with chat to close
                    the gaps between feedback and action.
                  </p>
                </div>

                <div className="mb-4">
                  <h5 className="text-black fw-bold">Experience & Precision</h5>

                  <p className="text-muted">
                    Create multiple discussions to keep all relevant
                    conversations together in one place.
                  </p>
                </div>

                <div>
                  <h5 className="text-black fw-bold">Experts About Business</h5>

                  <p className="text-muted">
                    Our experienced professionals provide reliable
                    business solutions for your organization.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section className="py-5">
        <div className="container py-5">
          <div className="text-center mb-5">
            <div className="text-black text-uppercase">
              Our Experts
            </div>

            <h2 className="fw-bold text-black">
              Our{" "}
              <span className="text">
               Professional Team
              </span>
            </h2>
          </div>

          <div className="row g-4">
            {team.map((member, index) => (
              <div className="col-lg-4 col-md-6" key={index}>
                <div className="card border-0 shadow-sm overflow-hidden">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="card-img-top"
                    style={{
                      height: "500px",
                      objectFit: "cover",
                    }}
                  />

                  <div className="card-body text-center">
                    <h4>{member.name}</h4>

                    <p className="text-muted mb-0">
                      {member.designation}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>



      <section className="map-section">
        <h1 className="text text-center">Google map</h1>
        <iframe
          className="w-100"
          title="Google Map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2136.986005919501!2d-73.9685579655238!3d40.75862446708152!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c258e4a1c884e5%3A0x24fe1071086b36d5!2sThe%20Atrium!5e0!3m2!1sen!2sbd!4v1585132512970!5m2!1sen!2sbd"
          height="450"
          style={{ border: 0 }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        ></iframe>
      </section>
      <Footer />
    </>
  );
};

export default Home;

