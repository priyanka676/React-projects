
import emailjs from "@emailjs/browser";

export const sendContactEmail = async ({
  name,
  email,
  subject,
  message,
}) => {
  return emailjs.send(
    "service_y96p66t",
    "template_1c37f6h",
    {
      from_name: name,
      from_email: email,
      subject: subject,
      message: message,
      reply_to: email,
    },
    {
      publicKey: "oYBoBLl1zNYEdbj9o",
    }
  );
};

