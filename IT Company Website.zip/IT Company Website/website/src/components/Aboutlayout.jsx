import React from 'react'
import { Link } from 'react-router-dom'

const Aboutlayout = () => {
  return (
<section>
<header className="main-header style-two">
        <div className="header-top">
            <div className="auto-container">
                <div className="inner-container clearfix">
					
					<div className="top-left">
						
						<ul className="info-list">
							<li><a href="mailto:itsolution@gmail.com"><span className="icon icofont-envelope"></span> itsolution@gmail.com</a></li>
							<li><a href="tel:+1212-226-3126"><span className="icon icofont-phone"></span> +1212-226-3126</a></li>
							<li><a href="contact.html"><span className="icon icofont-clock-time"></span> Mon - Sat: 8.00 - 17.00, Sunday Closed</a></li>
						</ul>
					</div>
					
				
                    <div className="top-right pull-right">
					
						<ul className="social-box">
							<li className="share">Our Social</li>
							<li><a href="https://twitter.com/" className="icofont-twitter"></a></li>
							<li><a href="http://facebook.com/" className="icofont-facebook"></a></li>
							<li><a href="https://www.instagram.com/" className="icofont-instagram"></a></li>
							<li><a href="https://rss.com/" className="icofont-rss"></a></li>
							<li><a href="https://www.youtube.com/" className="icofont-play-alt-1"></a></li>
						</ul>
                    </div>
					
                </div>
            </div>
        </div>
		
    
        <div className="header-upper">
        	<div className="auto-container">
            	<div className="inner-container clearfix">
                	
                	<div className="pull-left logo-box">
                    	<div className="logo">
							<Link to="/home">
                            {/* <img src="images/logo.png" alt="" title="" /> */}
							<div className='d-flex mt-4'>
							<i class="fa-solid fa-globe" style={{fontSize:"30px",color:"#2c724f"}}></i>
							<h3 className='text fw-bolder' style={{fontSize:"25px"}}>Best IT Solution</h3>
							</div>
							</Link></div>
                    </div>
					
                   	<div className="nav-outer pull-left clearfix">
					
						<nav className="main-menu navbar-expand-md">
							<div className="navbar-header">
								<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<span className="icon-bar"></span>
									<span className="icon-bar"></span>
									<span className="icon-bar"></span>
								</button>
							</div>

							<div className="navbar-collapse show collapse clearfix" id="navbarSupportedContent">
								<ul className="navigation clearfix">
									<li><Link to="/home">Home</Link></li>
									<li>
										<Link to="/about">About Us</Link></li>
									<li className="dropdown">
										<Link to="/service">Service</Link></li>
										<li>
												<Link to="/servicedetail">Service Detail</Link></li>
										
									
									<li className="dropdown">
										<Link to="/project">Projects</Link>
									</li>
									<li className="dropdown">
										<Link to="/blog">Blog</Link>
										
										
									</li>
									<li><Link to="/contact">Contact</Link></li>
								</ul>
						
							</div>
							
						</nav>
						
					</div>
					
					
					<div className="outer-box">
						
						<div className="search-box-btn search-box-outer"><span className="icon icofont-search"></span></div>
						
                        <div className="mobile-nav-toggler"><span className="icon ti-menu"></span></div>
					</div>
                   
                </div>
            </div>
        </div>
     
        <div className="mobile-menu">
            <div className="menu-backdrop"></div>
            <div className="close-btn"><span className="icon lnr lnr-cross"></span></div>
            
            <nav className="menu-box">
                <div className="nav-logo"><a href="index.html">
                    <img src="images/logo.png" alt="" title="" /></a></div>
                <div className="menu-outer"></div>
            </nav>
        </div>
		
    </header>
</section>
  )
}

export default Aboutlayout