
import React, { useRef, useState } from "react";
import Aboutlayout from "./Aboutlayout";
import Footer from "./Footer";
import { sendContactEmail } from "./emailService";

const Contact = () => {
  const formRef = useRef(null);

  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState({
    type: "",
    text: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formRef.current) return;

    const form = new FormData(formRef.current);

    const contactData = {
      name: form.get("name"),
      email: form.get("email"),
      subject: form.get("subject") || "General Inquiry",
      message: form.get("message"),
    };

    setSending(true);
    setStatus({ type: "", text: "" });

    try {
      await sendContactEmail(contactData);

      setStatus({
        type: "success",
        text: "Thank you! Your message has been sent successfully.",
      });

      formRef.current.reset();
    } catch (error) {
      console.error("EmailJS error:", error);

      setStatus({
        type: "error",
        text:
          error?.text ||
          error?.message ||
          "Unable to send your message. Please try again.",
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <Aboutlayout />

      <section className="contact-page-section mt-5 pt-5">
        <div className="auto-container container">

          {/* Contact Information */}
          <div className="contact-info-boxed mb-5">
            <div className="row g-4">

              <div className="column col-lg-6 col-md-6 col-sm-12">
                <h2 className="mt-3">
                  Brooklyn, <span>New York</span>
                </h2>

                <div className="text">
                  849 Diamond Str, 07th Floor, NY 10012,
                  New York, United State America
                </div>

                <div className="email mt-3">
                  Email:{" "}
                  <a href="mailto:infor@consulte.co">
                    infor@consulte.co
                  </a>
                  <div className="mt-5">
                    <h5>Connect with us</h5>
                  <i class="fa-brands fa-square-facebook" style={{fontSize:"30px"}}></i>
                  <i class="fa-brands fa-instagram" style={{fontSize:"30px"}}></i>
                  <i class="fa-brands fa-twitter"  style={{fontSize:"30px"}}></i>
                  <i class="fa-brands fa-linkedin"  style={{fontSize:"30px"}}></i>
                  </div>
                </div>
              </div>

              <div className="column col-lg-6 col-md-6 col-sm-12">
                <div className="call">
                  Call directly:
                  <br />
                  <a href="tel:+12122263126">
                    +1 212-226-3126
                  </a>
                </div>

                <ul className="location-list mt-3">
                  <li>
                    <span>Brand Offices: </span>
                    Allentown PA | Atlanta, GA | Chicago, IL |
                    Dallas, TX, Edison, NJ | Houston, TX
                  </li>

                  <li className="mt-2">
                    <span>Work Hours: </span>
                    Mon - Sat: 8.00 - 17.00, Sunday closed
                  </li>
                </ul>
              </div>

            </div>
          </div>

          {/* Contact Form */}
          <div className="form-boxed">
            <div className="sec-title centered text-center mb-4">
              <div className="title">CONTACT US</div>

              <h2>
                We Are Always Here{" "}
                <span>To Help You</span>
              </h2>

              <p>
                Have questions or need assistance?
                Send us a message.
              </p>
            </div>

            <div className="boxed-inner">
              <div className="contact-form">

                <form
                  ref={formRef}
                  onSubmit={handleSubmit}
                  id="contact-form"
                >
                  <div className="row g-3">

                    <div className="col-lg-4 col-md-6 col-sm-12">
                      <input
                        className="form-control"
                        type="text"
                        name="name"
                        placeholder="Name *"
                        autoComplete="name"
                        required
                      />
                    </div>

                    <div className="col-lg-4 col-md-6 col-sm-12">
                      <input
                        className="form-control"
                        type="email"
                        name="email"
                        placeholder="Email Address *"
                        autoComplete="email"
                        required
                      />
                    </div>

                    <div className="col-lg-4 col-md-12 col-sm-12">
                      <input
                        className="form-control"
                        type="text"
                        name="subject"
                        placeholder="Subject (Optional)"
                      />
                    </div>

                    <div className="col-lg-12 col-md-12 col-sm-12">
                      <textarea
                        className="form-control"
                        name="message"
                        rows="6"
                        placeholder="Message *"
                        required
                      />
                    </div>

                    <div className="col-lg-12 text-center mt-4">
                      <button
                        className="theme-btn btn-style-one"
                        type="submit"
                        disabled={sending}
                      >
                        <span className="txt">
                          {sending
                            ? "Sending..."
                            : "Send Message"}
                        </span>
                      </button>
                    </div>

                  </div>
                </form>

                {/* Success / Error Message */}
                {status.text && (
                  <div
                    className={`alert ${
                      status.type === "success"
                        ? "alert-success"
                        : "alert-danger"
                    } mt-4 text-center`}
                    role={
                      status.type === "error"
                        ? "alert"
                        : "status"
                    }
                  >
                    {status.text}
                  </div>
                )}

              </div>
            </div>
          </div>

        </div>
      </section>

      <Footer />
    </>
  );
};

export default Contact;

