import React from 'react'
import { Link } from 'react-router-dom';
import Aboutlayout from './Aboutlayout';
import Footer from './Footer';

const Service = () => {
	const clients = [
		"/images/clients/1.png",
		"/images/clients/2.png",
		"/images/clients/3.png",
		"/images/clients/4.png",
		"/images/clients/5.png",
		"/images/clients/1.png",
		"/images/clients/2.png",
		"/images/clients/3.png",
	  ];
  return (
	<>
	<Aboutlayout />
   <div>
    	
	
    <div className="service-banner-section" data-bg-image="images/resource/service-1.jpg">
		<div className="auto-container">
			<div className="content-box">
				<h2>Our <span>Services</span></h2>
				<div className="text">Capitalise on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional base clickthroughs.</div>
				<a href="contact.html" className="theme-btn btn-style-one"><span className="txt">get in touch</span></a>
				
				
				<div className="lower-box clearfix">
					<div className="pull-left">
						<div className="book pt-2">
							<span className="icon icofont-phone"></span>
							book through <br /> call now
							
						</div>
					</div>
					
				</div>
				
			</div>
			
		</div>
	</div>
	
	<div className="services-section section-padding">
		<div className="auto-container">
			<div className="sec-title">
				<div className="title">our services</div>
				<h2><span> Providing Best Technologies</span></h2>
			</div>
			<div className="inner-container">
				<div className="row g-0">
				
				
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-blackboard"></span>
							</div>
							<i class="fa-solid fa-handshake" style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">Web Development</Link></h5>
							
							<div className="text">Thought leadership pass the clap hackathon wearables.</div>
							<Link className="read-more" to="/servicedetail">More <span classNameName="ti-angle-right"></span></Link>
						</div>
					</div>
					
					
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-stats-up"></span>
							</div>
							<i class="fa-solid fa-coins"  style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">Mobile Apps</Link></h5>
							<div className="text">Platform omnichannel click thought leadership pivot</div>
							<Link className="read-more" to="/servicedetail">More <span className="ti-angle-right"></span></Link>
						</div>
					</div>
					
				
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-shield"></span>
							</div>
							<i class="fa-solid fa-house-flood-water-circle-arrow-right"  style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">Cloud & Devops</Link></h5>
							<div className="text">Disrupt taste makers help council emerging.</div>
							<Link className="read-more" to="/servicedetail">More <span className="ti-angle-right"></span></Link>
						</div>
					</div>
					
					
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-home"></span>
							</div>
							<i class="fa-regular fa-building" style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">Ai Automation</Link></h5>
							<div className="text">Mobile ready proprietary dedication intuitive</div>
							<Link className="read-more" to="/servicedetail">More <span className="ti-angle-right"></span></Link>
						</div>
					</div>
					
					
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-stamp"></span>
							</div>
							<i class="fa-solid fa-layer-group" style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">UI UX Design</Link></h5>
							<div className="text">Thought leadership pass the clap hackathon wearables.</div>
							<Link className="read-more" to="/servicedetail">More <span className="ti-angle-right"></span></Link>
						</div>
					</div>
					
					
					<div className="service-block col-lg-4 col-md-6 col-sm-12">
						<div className="inner-box">
							<div className="icon-box">
								<span className="icon ti-money"></span>
							</div>
							<i class="fa-solid fa-money-bill-trend-up" style={{fontSize:"50px"}}></i>
							<h5><Link to="/servicedetail">Support and Security</Link></h5>
							<div className="text">Disrupt taste makers help council emerging.</div>
							<Link className="read-more" to="/servicedetail">More <span className="ti-angle-right"></span></Link>
						</div>
					</div>
					
					
				
					
					
				
					
				</div>
				
			</div>
		</div>
	</div>
	




	<div className="reputation-section-two style-two">
		<div className="auto-container">
			<div className="row clearfix">
				
				
				<div className="form-column col-lg-5 col-md-12 col-sm-12">
					<div className="inner-column">
						<div className="form-boxed">
							<h5>Connect with Us</h5>
							
							<div className="consult-form">
								<form method="post" action="https://htmldemo.net/consultix/consultix/donate.html">

									
									<div className="form-group">
										<label>full name</label>
										<input type="text" name="name" value="" placeholder="Jason Staham" required />
									</div>
								
									<div className="form-group">
										<label>phone number</label>
										<input type="text" name="phone" value="" placeholder="Enter your phone number" required />
									</div>
									
									<div className="form-group">
										<label>topics</label>
										<select className="custom-select-box">
											<option>Choose topic</option>
											<option>Topic 01</option>
											<option>Topic 02</option>
											<option>Topic 03</option>
											<option>Topic 04</option>
										</select>
									</div>
									
									<div className="form-group">
										<label>message</label>
										<textarea name="message" placeholder="Write your message here"></textarea>
									</div>
									<div className="form-group">
										<button className="theme-btn btn-style-one" type="submit" name="submit-form"><span className="txt">send your messenger</span></button>
									</div>
								</form>
							
							</div>
						</div>
						
					</div>
				</div>
				
				
				<div className="content-column col-lg-7 col-md-12 col-sm-12">
					<div className="inner-column">
						<div className="sec-title">
							<div className="title">why choose us</div>
							<h2><span>Your Successful </span>Is<br /> Our Reputation</h2>
						</div>
						<div className="blocks-outer">
							
							
							<div className="reputation-block">
								<div className="inner-box">
									<h5>Strong Martket Analysis</h5>
									<div className="text">Tasks, docs, and files integrate with Arado’s chat to close the <br /> gaps between feedback and action.</div>
								</div>
							</div>
							
							
							<div className="reputation-block">
								<div className="inner-box">
									<h5>Experience & Percision</h5>
									<div className="text">Create multiple discussions to keep all relevant conversations <br /> together, all in one place with Arado</div>
								</div>
							</div>
							
							
							<div className="reputation-block">
								<div className="inner-box">
									<h5>Experts About Business</h5>
									<div className="text">Create multiple discussions to keep all relevant conversations <br /> together, all in one place with Arado</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	
	<div className="testimonial-section">
		<div className="auto-container">
			<div className="inner-container">
			
				
				<div className="sec-title">
					<div className="title">testimonials</div>
					<h2><span>+2,500 Clients </span>Love Us</h2>
				</div>
				<div className="testimonial-carousel owl-carousel owl-theme">
					
					
					<div className="testimonial-block">
						<div className="inner-box">
							<div className="quote icofont-quote-right"></div>
							<div className="author">Ryan Betthalyn <span>/ Director at Chobham Manor</span></div>
							<div className="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
						</div>
					</div>
					
					
					<div className="testimonial-block">
						<div className="inner-box">
							<div className="quote icofont-quote-right"></div>
							<div className="author">Bobs Hanley <span>/ Director at Spotify</span></div>
							<div className="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
						</div>
					</div>
					
					
					<div className="testimonial-block">
						<div className="inner-box">
							<div className="quote icofont-quote-right"></div>
							<div className="author">Ryan Betthalyn <span>/ Director at Chobham Manor</span></div>
							<div className="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
						</div>
					</div>
					
					
					<div className="testimonial-block">
						<div className="inner-box">
							<div className="quote icofont-quote-right"></div>
							<div className="author">Bobs Hanley <span>/ Director at Spotify</span></div>
							<div className="text">Sed elit quam, iaculis sed semper sit amet udin vitae nibh. Rubino at magna akal semperFusce commodo molestie luctus.Lorem ipsum Dolor tusima olatiup.</div>
						</div>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
	

   </div>
   <Footer />
   </>
  )
}

export default Service;