import React from 'react'
import Aboutlayout from './Aboutlayout'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Project = () => {
  return (
    <>
	<Aboutlayout />

    
   <section>
    

    <div className="page-title-section">
    	<div className="auto-container">
			<ul className="post-meta">
				<li><a href="index.html">Index</a></li>
				<li>Project</li>
			</ul>
			<h2><span>Latest</span> From Our Project</h2>
		</div>
	</div>

	<div className="project-section section-padding">
		<div className="auto-container">
			<div className="row">

				
				<div className="col-lg-4 col-md-6 col-12">
					<div className="work-left work-details">
						<div className="portfolio-main-info">
							<h2 className="title">Our Project</h2>
							
							<div className="work-details-list mt-60">

								<div className="details-list">
									<label>Date</label>
									<span>28 Sep 2007</span>
								</div>

								<div className="details-list">
									<label>Client</label>
									<span>HighGrove Partners</span>
								</div>

								<div className="details-list">
									<label>Categories</label>
									<span><a href="#">Digital</a></span>
								</div>

								<div className="details-list">
									<label>Awards</label>
									<span>2015 Digital World Awards 2016 Finale Awards</span>
								</div>

							</div>
							
							<div className="work-share section-padding-top-70">
								<h6 className="heading heading-h6">SHARE</h6>
							</div>
						</div>
					</div>
				</div>


			
				<div className="col-lg-7 col-md-6 offset-lg-1 col-12">
					<div className="work-left work-details mt-lg-30">
						<div className="work-main-info">
							<div className="work-content">
								<h6 className="title">ABOUT THE PROJECT</h6>

								<div className="desc mt-40">
									<div className="content mb-25">
										<p>Digital marketing encompasses all marketing efforts
											that use an electronic device or the internet. Businesses leverage
											digital channels such as search engines, social media, email, and
											their websites to connect with current and prospective customers.</p>
									</div>
									<div className="content mb-25">
										<p>It is. In fact, “constant” internet usage among
											adults increased by 5% in just the last three years, according to
											Pew Research. And although we say it a lot, the way people shop and
											buy really has changed along with it — meaning offline marketing
											isn’t as effective as it used to be.</p>
									</div>
									<div className="content mb-60">
										<p>Marketing has always been about connecting with your
											audience in the right place and at the right time. Today, that
											means you need to meet them where they are already spending time:
											on the internet. (Source: blog.hubspot.com)</p>
									</div>

									<div className="work-btn">
										<a className="theme-btn btn-style-one" href="#"><span class="txt">Go to link</span></a>
									</div>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		
			

			
		
			
			<div className="custom-layout-gallery mt-lg-100">
				<div className="row mb-n30">
					<div className="col-lg-6 col-md-6 col-12">
						<div className="thumbnail">
							<img className="w-100" src="images/project/project-3.jpg" alt="finance" />
						</div>
					</div>
					<div className="col-lg-6 col-md-6 col-12 mt-50">
						<div className="thumbnail">
							<img className="w-100" src="images/project/project-4.jpg" alt="finance" />
						</div>
					</div>

					<div className="row mt-lg-100">
				<div className="col-lg-4 col-md-12 col-12">
					<div className="digital-marketing">
						<h3 className="heading heading-h3">Digital Marketing.</h3>
					</div>
				</div>
				<div className="col-lg-7 col-md-12 col-12 offset-lg-1">
					<div className="digital-marketing mt-30">
						<div className="inner">
							<p>Marketing has always been about connecting with your audience in
								the right place and at the right time. Today, that means you need to meet them
								where they are already spending time: on the internet. A seasoned inbound
								marketer might say inbound marketing and digital marketing are virtually the
								same thing, but there are some minor differences. And conversations with
								marketers and business owners in the U.S., U.K., Asia, Australia, and New
								Zealand, I've learned a lot about how those small differences are being
								observed across the world.</p>
						</div>
					</div>
				</div>
			</div>
				</div>
			</div>
			


		</div>
	</div>
	
  </section>
  <Footer />
  </>
  )
}

export default Project