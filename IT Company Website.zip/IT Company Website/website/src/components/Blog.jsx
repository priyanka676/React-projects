import React from 'react'
import Aboutlayout from './Aboutlayout'
import Footer from './Footer'
import { Link } from 'react-router-dom'

const Blog = () => {
  return (
	<>
	<Aboutlayout />
    <section>
	
        <div className="page-title-section">
    	<div className="auto-container">
			<ul className="post-meta">
				<li><Link href="/home">Index</Link></li>
				<li>Blog</li>
			</ul>
			<h2><span>Latest</span> Blog post</h2>
		</div>
	</div>

    <div className="sidebar-page-container padding-top">
    	<div className="auto-container">
			<div className="row clearfix">
            	
               
                <div className="content-side col-lg-9 col-md-12 col-sm-12">
					<div className="our-blogs">
						
					
						<div className="news-block-three">
							<div className="inner-box">
								<div className="image">
									<Link to="/blogdetails">
                    <img src="images/image2.jpg" alt="" /></Link>
								</div>
								<div className="title">A Junior Developer’s Roadmap</div>
								<h4><Link to="/blogdetails">From Internship to First Job</Link></h4>
								<div className="post-date">Decmber 14th, 2020 by <span>Admin</span></div>
							</div>
						</div>
						
			
						<div className="news-block-three">
							<div className="inner-box">
								<div className="image">
									<Link to="/blogdetails">
                    <img src="images/image3.jpg" alt="" /></Link>
								</div>
								<div className="title">How a Custom Website</div>
								<h4><Link to="/blogdetails">Can Grow Your Business Online</Link></h4>
								<div className="post-date">Decmber 14th, 2020 by <span>Admin</span></div>
							</div>
						</div>
						
					
						<div className="news-block-three">
							<div className="inner-box">
								<div className="image">
									<Link to="/blogdetails">
                               <img src="images/myimage3.jpg" alt="" /></Link>
								</div>
								<div className="title">REST API Best Practices</div>
								<h4><Link to="/blogdetails">Every Node.js Developer Should Follow</Link></h4>
								<div className="post-date">Decmber 14th, 2020 by <span>Admin</span></div>
							</div>
						</div>
						
					
						<div className="news-block-three">
							<div className="inner-box">
								<div className="image">
									<Link to="/blogdetails">
                    <img src="images/myimag1.jpg" alt="" /></Link>
								</div>
								<div className="title">Website Speed Matters</div>
								<h4><Link to="/blogdetails">More Than You Think</Link></h4>
								<div className="post-date">Decmber 14th, 2020 by <span>Admin</span></div>
							</div>
						</div>
						
					
						<div className="news-block-three">
							<div className="inner-box">
								<div className="image">
									<Link to="/blogdetails">
                    <img src="images/myimage2.jpg" alt="" /></Link>
								</div>
								<div className="title">Basic SEO Checklist for</div>
								<h4><Link to="/blogdetails">Every New Website</Link></h4>
								<div className="post-date">Decmber 14th, 2020 by <span>Admin</span></div>
							</div>
						</div>
						
					</div>
					
					
					<div className="styled-pagination">
						<ul className="clearfix">
							<li><a href="#">1</a></li>
							<li className="active"><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li className="next"><a href="#"><span className="ti-angle-right"></span> </a></li>
						</ul>
					</div>
					
				</div>
				
				
                <div className="sidebar-side col-lg-3 col-md-12 col-sm-12">
                	<aside className="sidebar sticky-top margin-left">
						
				
                        <div className="sidebar-widget search-box">
							<div className="sidebar-title">
                            	<h4>Search</h4>
                            </div>
                        	<form method="post" action="https://htmldemo.net/consultix/consultix/contact.html">
                                <div className="form-group">
                                    <input type="search" name="search-field" value="" placeholder="Type & Hit Enter..." required />
                                    <button type="submit"><span className="icon fa fa-search"></span></button>
                                </div>
                            </form>
						</div>
						
					
                        <div className="sidebar-widget categories-blog">
                        	<div className="sidebar-title">
                            	<h4>Categories</h4>
                            </div>
                            <ul>
								<li><a href="#">All <span>25</span></a></li>
								<li><a href="#">News <span>12</span></a></li>
								<li><a href="#">business <span>7</span></a></li>
								<li><a href="#">tips & tricks <span>4</span></a></li>
								<li><a href="#">Others <span>2</span></a></li>
							</ul>
                        </div>
						
						
                        <div className="sidebar-widget popular-posts">
							<div className="sidebar-title">
                            	<h4>Recent Posts</h4>
                            </div>
                            <div className="widget-content">
                                <div className="post">
                                    <figure className="post-thumb"><a href="blog-single.html">
                                      <img src="images/resource/post-thumb-1.jpg" alt="" /></a></figure>
                                    <div className="text">
										<Link to="/blogdetails">How AI Is Changing Web Development in 2026</Link></div>
								</div>
                                
                                <div className="post">
                                    <figure className="post-thumb"><a href="blog-single.html">
                                      <img src="images/resource/post-thumb-2.jpg" alt="" /></a></figure>
                                    <div className="text">
										<Link to="/blogdeatils">Building an AI-Powered Web App: Where to Start</Link></div>
                                </div>
                                
                                <div className="post">
                                    <figure className="post-thumb"><a href="blog-single.html">
                                      <img src="images/resource/post-thumb-3.jpg" alt="" /></a></figure>
                                    <div className="text">
										<Link to="/blogdetails">Portfolio Projects That Actually Impress Recruiters</Link></div>
                                </div>
                            </div>
						</div>
						
					
                        <div className="sidebar-widget tags">
							<div className="sidebar-title">
                            	<h4>Tags</h4>
                            </div>
							<div className="widget-content">
								<a href="#">Structure</a>
								<a href="#">Envato</a>
								<a href="#">Premium</a>
								<a href="#">Clean</a>
								<a href="#">WordPress</a>
							</div>
						</div>
						
					</aside>
				</div>
				
			</div>
		</div>
	</div>
	
    </section>
	<Footer />
	</>
  )
}

export default Blog