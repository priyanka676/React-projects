import React from 'react'
import Navbar from '../components/Navbar'
import { Outlet } from 'react-router-dom'
import Home from '../components/Home'
import Footer from '../components/Footer'

const Layout = () => {
  return (
    <div>
    <Navbar />
    <Outlet />
    <Home />
    <Footer />
    </div>

    
  )
}

export default Layout