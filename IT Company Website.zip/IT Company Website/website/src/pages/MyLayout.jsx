import React from 'react'
import Aboutlayout from '../components/Aboutlayout'
import Footer from '../components/Footer'
import { Outlet } from 'react-router-dom'

const MyLayout = () => {
  return (
    <>
   <Aboutlayout />
   <Outlet />
   <Footer />
   </>

  )
}

export default MyLayout