// Scroll-reveal engine (no dependencies).
// Tags elements with data-anim="<type>" and reveals them with an
// IntersectionObserver. The look of each type lives in animations.css.

// Parts of the page that must never be tagged.
const EXCLUDE = [
  'header',
  '.main-header',
  '.mobile-menu',
  '.search-popup',
  '.scroll-to-top',
  '.scroll-progress',
  '.banner-section .content-column', // has its own slider-based animation
  '.owl-carousel',
].join(',')

// Order matters: big blocks first, then images, then text.
// A child of an already-tagged element is skipped (no double animation).
const GROUPS = [
  {
    type: 'up',
    sel: [
      '.service-block',
      '.team-block',
      '.news-block',
      '.news-block-two',
      '.news-block-three',
      '.news-block-four',
      '.testimonial-block',
      '.reputation-block',
      '.sidebar-widget',
      '.category-boxed',
      '.accordion-box .block',
      '.details-list',
      '.footer-widget',
      '.card',
      '.contact-info-boxed',
      '.form-boxed',
      '.consult-form',
      '.work-details-list',
    ].join(','),
  },
  { type: 'zoom', sel: '.gallery-block, .project-section .inner-column' },
  {
    type: 'left',
    sel: '.about-image, .image-column, .work-left, .page-banner-image-section',
  },
  { type: 'zoom', sel: 'main img, section img, .container img, .auto-container img' },
  {
    type: 'right',
    sel: '.form-column, .content-column .inner-column, .blog-detail .inner-box',
  },
  {
    type: 'up',
    sel: [
      '.sec-title',
      '.page-title-section h2',
      '.page-title-section .post-meta',
      '.service-title-box',
      'section h1',
      'section h2',
      'section h3',
      'section h4',
      'section p',
      'section blockquote',
      '.container h1',
      '.container h2',
      '.container h3',
      '.container p',
      '.auto-container h1',
      '.auto-container h2',
      '.auto-container h3',
      '.auto-container p',
      '.lower-box',
      '.signature',
      '.theme-btn',
      '.btn-style-one',
      '.btn',
      '.styled-pagination',
      '.post-share-options',
      '.comment-form',
      '.contact-form',
    ].join(','),
  },
]

const STAGGER_MS = 90
const MAX_DELAY_MS = 450

export function initReveal(root = document) {
  if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
    return () => {}
  }
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    return () => {}
  }

  const isTagged = (el) => el.hasAttribute('data-anim')

  const tag = () => {
    GROUPS.forEach(({ type, sel }) => {
      const perParent = new Map()
      root.querySelectorAll(sel).forEach((el) => {
        if (isTagged(el)) return
        if (el.closest(EXCLUDE)) return
        // skip if an ancestor is already animating
        const parent = el.parentElement
        if (parent && parent.closest('[data-anim]')) return

        const index = perParent.get(parent) ?? 0
        perParent.set(parent, index + 1)

        el.setAttribute('data-anim', type)
        el.style.setProperty(
          '--anim-delay',
          `${Math.min(index * STAGGER_MS, MAX_DELAY_MS)}ms`,
        )
      })
    })
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return
        entry.target.setAttribute('data-anim-in', '')
        observer.unobserve(entry.target)
      })
    },
    { threshold: 0.12, rootMargin: '0px 0px -8% 0px' },
  )

  const observePending = () => {
    root
      .querySelectorAll('[data-anim]:not([data-anim-in])')
      .forEach((el) => observer.observe(el))
  }

  tag()
  observePending()

  // Safety net: never leave content hidden.
  const failSafe = window.setTimeout(() => {
    root
      .querySelectorAll('[data-anim]:not([data-anim-in])')
      .forEach((el) => {
        const r = el.getBoundingClientRect()
        if (r.top < window.innerHeight) el.setAttribute('data-anim-in', '')
      })
  }, 2500)

  // Pick up content that React renders after the first pass.
  const mutation = new MutationObserver(() => {
    tag()
    observePending()
  })
  mutation.observe(root === document ? document.body : root, {
    childList: true,
    subtree: true,
  })

  return () => {
    window.clearTimeout(failSafe)
    observer.disconnect()
    mutation.disconnect()
  }
}
