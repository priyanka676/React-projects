function displayAge() {
    const inputDate = document.getElementById("birthdate").value;
    const resultDiv = document.getElementById("result");

   
    if (!inputDate) {
        resultDiv.textContent = "Please select a valid date.";
        return;
    }

    const today = new Date();
    const birthDate = new Date(inputDate);

  
    if (birthDate > today) {
        resultDiv.textContent = "Birthdate cannot be in the future!";
        return;
    }

    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    if (days < 0) {
        months--;
        const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
        days += prevMonth.getDate();
    }

    if (months < 0) {
        years--;
        months += 12;
    }

  
    resultDiv.textContent = `You are ${years} years, ${months} months, and ${days} days old.`;
}