const str = "RANA PRIYANKA";
console.log(str.split("").reverse().join("")); 