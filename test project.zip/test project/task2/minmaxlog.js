const numbers = [5, 2, 9, 1, 7];
console.log("Min:", Math.min(...numbers)); 
console.log("Max:", Math.max(...numbers));
