const numbers = [5, 2, 9, 1, 7];

const min = numbers.reduce((a, b) => Math.min(a, b));
const max = numbers.reduce((a, b) => Math.max(a, b));

console.log("Min:", min); 
console.log("Max:", max);