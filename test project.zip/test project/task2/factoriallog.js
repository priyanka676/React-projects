function getFactorial(num) {
    if (num < 0) return "Undefined for negative numbers";
    
    let result = 1;
    for (let i = 2; i <= num; i++) {
        result *= i;
    }
    return result;
}

console.log(getFactorial(5));